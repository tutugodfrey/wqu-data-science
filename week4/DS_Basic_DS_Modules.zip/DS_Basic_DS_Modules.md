

```python
%matplotlib inline
import matplotlib
import seaborn as sns
matplotlib.rcParams['savefig.dpi'] = 144
```


```python
import expectexception
```

# Basic data tools: NumPy, Matplotlib, Pandas

Python is a powerful and flexible programming language, but it doesn't have built-in tools for mathematical analysis or data visualization. For most data analysis we will rely on some helpful libraries. We'll explore three libraries that are very common for data analysis and visualization.

## NumPy

First among these is NumPy. The main NumPy features are three-fold: its mathematical functions (e.g. `sin`, `log`, `floor`), its `random` submodule (useful for random sampling), and the NumPy `ndarray` object.

A NumPy array is similar to a mathematical n-dimensional matrix. For example, 

$$\begin{bmatrix}
    x_{11} & x_{12} & x_{13} & \dots  & x_{1n} \\
    x_{21} & x_{22} & x_{23} & \dots  & x_{2n} \\
    \vdots & \vdots & \vdots & \ddots & \vdots \\
    x_{d1} & x_{d2} & x_{d3} & \dots  & x_{dn}
\end{bmatrix}$$

A NumPy array could be 1-dimensional (e.g. [1, 5, 20, 34, ...]), 2-dimensional (as above), or many dimensions. It's important to note that all the rows and columns of the 2-dimensional array are the same length. That will be true for all dimensions of arrays.

Let's contrast this with lists.


```python
# to access NumPy, we have to import it
import numpy as np
```


```python
list_of_lists = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(list_of_lists)
```

    [[1, 2, 3], [4, 5, 6], [7, 8, 9]]



```python
an_array = np.array(list_of_lists)
print(an_array)
```

    [[1 2 3]
     [4 5 6]
     [7 8 9]]



```python
print(an_array.shape)
print(an_array.dtype)
type(an_array)
```

    (3, 3)
    int64





    numpy.ndarray




```python
non_rectangular = [[1, 2], [3, 4, 5], [6, 7, 8, 9]]
print(non_rectangular)
```

    [[1, 2], [3, 4, 5], [6, 7, 8, 9]]



```python
non_rectangular_array = np.array(non_rectangular)
print(non_rectangular_array)
```

    [list([1, 2]) list([3, 4, 5]) list([6, 7, 8, 9])]


Why did these print differently? Let's investigate their _shape_ and _data type_ (`dtype`).


```python
print(an_array.shape, an_array.dtype)
print(non_rectangular_array.shape, non_rectangular_array.dtype)
```

    (3, 3) int64
    (3,) object


The first case, `an_array`, is a 2-dimensional 3x3 array (of integers). In contrast, `non_rectangular_array` is a 1-dimensional length 3 array (of _objects_, namely `list` objects).

We can also create a variety of arrays with NumPy's convenience functions.


```python
# Inclusive of the upper band

np.linspace(1, 10, 10)
```




    array([ 1.,  2.,  3.,  4.,  5.,  6.,  7.,  8.,  9., 10.])




```python
# exclusive of the upper band
np.arange(1, 10, 1)
```




    array([1, 2, 3, 4, 5, 6, 7, 8, 9])




```python
np.logspace(1, 10, 10)
```




    array([1.e+01, 1.e+02, 1.e+03, 1.e+04, 1.e+05, 1.e+06, 1.e+07, 1.e+08,
           1.e+09, 1.e+10])




```python
np.zeros(10)
```




    array([0., 0., 0., 0., 0., 0., 0., 0., 0., 0.])




```python
np.zeros((10, 5, 2))
```




    array([[[0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.]],
    
           [[0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.]],
    
           [[0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.]],
    
           [[0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.]],
    
           [[0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.]],
    
           [[0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.]],
    
           [[0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.]],
    
           [[0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.]],
    
           [[0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.]],
    
           [[0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.],
            [0., 0.]]])




```python
np.zeros((2, 10, 5))
```




    array([[[0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.]],
    
           [[0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.],
            [0., 0., 0., 0., 0.]]])




```python
np.ones(10)
```




    array([1., 1., 1., 1., 1., 1., 1., 1., 1., 1.])




```python
np.ones((10, 2))
```




    array([[1., 1.],
           [1., 1.],
           [1., 1.],
           [1., 1.],
           [1., 1.],
           [1., 1.],
           [1., 1.],
           [1., 1.],
           [1., 1.],
           [1., 1.]])




```python
# diagonal metric
np.diag([1,2,3,4])
```




    array([[1, 0, 0, 0],
           [0, 2, 0, 0],
           [0, 0, 3, 0],
           [0, 0, 0, 4]])




```python
# diagonal metric
np.diag([1,2,3,4, 5, 6, 7, 8, 9])
```




    array([[1, 0, 0, 0, 0, 0, 0, 0, 0],
           [0, 2, 0, 0, 0, 0, 0, 0, 0],
           [0, 0, 3, 0, 0, 0, 0, 0, 0],
           [0, 0, 0, 4, 0, 0, 0, 0, 0],
           [0, 0, 0, 0, 5, 0, 0, 0, 0],
           [0, 0, 0, 0, 0, 6, 0, 0, 0],
           [0, 0, 0, 0, 0, 0, 7, 0, 0],
           [0, 0, 0, 0, 0, 0, 0, 8, 0],
           [0, 0, 0, 0, 0, 0, 0, 0, 9]])




```python
np.eye(5)
```




    array([[1., 0., 0., 0., 0.],
           [0., 1., 0., 0., 0.],
           [0., 0., 1., 0., 0.],
           [0., 0., 0., 1., 0.],
           [0., 0., 0., 0., 1.]])



We can also convert the `dtype` of an array after creation.


```python
print(np.logspace(1, 10, 10).dtype)
print(np.logspace(1, 10, 10).astype(int).dtype)
```

    float64
    int64



```python
np.array([False, True]).astype(float)
```




    array([0., 1.])



Why does any of this matter?

Arrays are often more efficient in terms of code as well as computational resources for certain calculations. Computationally this efficiency comes from the fact that we pre-allocate a contiguous block of memory for the results of our computation.

To explore the advantages in code, let's try to do some math on these numbers.

First let's simply calculate the sum of all the numbers and look at the differences in the necessary code for `list_of_lists`, `an_array`, and `non_rectangular_array`.


```python
sum([2, 3, True])
```




    6




```python
list_of_lists # defined above
```




    [[1, 2, 3], [4, 5, 6], [7, 8, 9]]




```python
print(sum([sum(inner_list) for inner_list in list_of_lists]))

print(an_array.sum())
```

    45
    45



```python
[sum(inner_list) for inner_list in list_of_lists]
```




    [6, 15, 24]




```python
an_array.sum(axis=0)
```




    array([12, 15, 18])




```python
an_array.sum(axis=1)
```




    array([ 6, 15, 24])




```python
[sum(row[index] for row in list_of_lists) for index in range(len(list_of_lists[0]))]
```




    [12, 15, 18]



Summing the numbers in an array is much easier than for a list of lists. We don't have to dig into a hierarchy of lists, we just use the `sum` method of the `ndarray`. Does this still work for `non_rectangular_array`?


```python
# what happens here?
print(non_rectangular_array.sum())
```

    [1, 2, 3, 4, 5, 6, 7, 8, 9]



```python
np.array([2, 4, 5, 6, 7])+ 5
```




    array([ 7,  9, 10, 11, 12])



Remember `non_rectangular_array` is a 1-dimensional array of `list` objects. The `sum` method tries to add them together: first list + second list + third list. Addition of lists results in _concatenation_.


```python
# concatenate three lists
print([1, 2] + [3, 4, 5] + [6, 7, 8, 9])
```

    [1, 2, 3, 4, 5, 6, 7, 8, 9]


The contrast becomes even more clear when we try to sum rows or columns individually.


```python
print('Array row sums: ', an_array.sum(axis=1))
print('Array column sums: ', an_array.sum(axis=0))
```

    Array row sums:  [ 6 15 24]
    Array column sums:  [12 15 18]



```python
print('List of list row sums: ', [sum(inner_list) for inner_list in list_of_lists])

def column_sum(list_of_lists):
    running_sums = [0] * len(list_of_lists[0])
    for inner_list in list_of_lists:
        for i, number in enumerate(inner_list):
            running_sums[i] += number
            
    return running_sums

print('List of list column sums: ', column_sum(list_of_lists))
```

    List of list row sums:  [6, 15, 24]
    List of list column sums:  [12, 15, 18]


Generally it is much more natural to do mathematical operations with arrays than lists.


```python
a = np.array([1, 2, 3, 4, 5])
print(a + 5) # add a scalar
print(a * 5) # multiply by a scalar
print(a / 5) # divide by a scalar (note the float!)
```

    [ 6  7  8  9 10]
    [ 5 10 15 20 25]
    [0.2 0.4 0.6 0.8 1. ]



```python
b = a + 1
print(a + b) # add together two arrays
print(a * b) # multiply two arrays (element-wise)
print(a / b.astype(float)) # divide two arrays (element-wise)
```

    [ 3  5  7  9 11]
    [ 2  6 12 20 30]
    [0.5        0.66666667 0.75       0.8        0.83333333]


Arrays can also be used for linear algebra, acting as vectors, matrices, tensors, etc.


```python
print(np.dot(a, b)) # inner product of two arrays
print(np.outer(a, b)) # outer product of two arrays
```

    70
    [[ 2  3  4  5  6]
     [ 4  6  8 10 12]
     [ 6  9 12 15 18]
     [ 8 12 16 20 24]
     [10 15 20 25 30]]


Arrays have a lot to offer us in terms of representing and analyzing data, since we can easily apply mathematical functions to data sets or sections of data sets. Most of the time we won't run into any trouble using arrays, but it's good to be mindful of the restrictions around shape and datatype.

These restrictions around `shape` and `dtype` allow the `ndarray` objects to be much more performant compared to a general Python `list`.  There are few reasons for this, but the main two result from the typed nature of the `ndarray`, as this allows contiguous memory storage and consistent function lookup.  When a Python `list` is summed, Python needs to figure out at runtime the correct way in which to add each element of the list together.  When an `ndarray` is summed, `NumPy` already knows the type of the each element (and they are consistent), thus it can sum them without checking the correct add function for each element.

Lets see this in action by doing some basic profiling.  First we will create a list of 100000 random elements and then time the sum function.


```python
time_list = [np.random.random() for _ in range(100000)]
time_arr = np.array(time_list)
```


```python
%%timeit 
sum(time_list)
```

    499 µs ± 8.08 µs per loop (mean ± std. dev. of 7 runs, 1000 loops each)



```python
%%timeit
np.sum(time_arr)
```

    49.7 µs ± 249 ns per loop (mean ± std. dev. of 7 runs, 10000 loops each)


### Universal functions

`NumPy` defines a `ufunc` which allows it to efficiently run functions over arrays.  Many of these functions are built in, such as `np.cos`, and implemented in highly performance compiled `C` code.  These functions can perform `broadcasting` which allows them to automatically handle operations between arrays of different shapes, for example two arrays with the same shape, or an array and a scalar.

### Changing Shape

Often we will want to take arrays that are one shape and transform them to a different shape more amenable to a specific operation.


```python
mat = np.random.rand(20, 10)
mat.shape
```




    (20, 10)




```python
mat.reshape(40, 5).shape
```




    (40, 5)




```python
%%expect_exception ValueError

mat.reshape(30, 5)
```

    [0;31m---------------------------------------------------------------------------[0m
    [0;31mValueError[0m                                Traceback (most recent call last)
    [0;32m<ipython-input-43-8f32a9a8072f>[0m in [0;36m<module>[0;34m()[0m
    [1;32m      1[0m [0;34m[0m[0m
    [0;32m----> 2[0;31m [0mmat[0m[0;34m.[0m[0mreshape[0m[0;34m([0m[0;36m30[0m[0;34m,[0m [0;36m5[0m[0;34m)[0m[0;34m[0m[0m
    [0m
    [0;31mValueError[0m: cannot reshape array of size 200 into shape (30,5)



```python
mat.ravel().shape
```




    (200,)




```python
mat.transpose().shape
```




    (10, 20)



### Combining arrays


```python
print(a)
print(b)
```

    [1 2 3 4 5]
    [2 3 4 5 6]



```python
np.hstack((a, b))
```




    array([1, 2, 3, 4, 5, 2, 3, 4, 5, 6])




```python
np.vstack((a, b))
```




    array([[1, 2, 3, 4, 5],
           [2, 3, 4, 5, 6]])




```python
np.dstack((a, b))
```




    array([[[1, 2],
            [2, 3],
            [3, 4],
            [4, 5],
            [5, 6]]])



### Basic data aggregation

Let's explore some more examples of using arrays, this time using NumPy's `random` submodule to create some "fake data". Simulating data is useful for testing and prototyping new techniques or code, and some algorithms even require random input.


```python
np.random.seed(42)
jan_coffee_sales = np.random.randint(25, 200, size=(4, 7))
print(jan_coffee_sales)
```

    [[127 117  39 131  96  45 127]
     [146  99 112 141 124 128 176]
     [155 174  77  26 112 182  62]
     [154  45 185  82  46 113  73]]



```python
# mean sales
print('Mean coffees sold per day in January: %d' % jan_coffee_sales.mean())
```

    Mean coffees sold per day in January: 110



```python
# mean sales for Monday
print('Mean coffees sold on Monday in January: %d' % jan_coffee_sales[:, 1].mean())
```

    Mean coffees sold on Monday in January: 108



```python
# day with most sales
# remember we count dates from 1, not 0!
print('Day with highest sales was January %d' % (jan_coffee_sales.argmax() + 1))
```

    Day with highest sales was January 24



```python
# is there a weekly periodicity?
from fractions import Fraction

normalized_sales = (jan_coffee_sales - jan_coffee_sales.mean()) / abs(jan_coffee_sales - jan_coffee_sales.mean()).max()
frequencies = [Fraction.from_float(f).limit_denominator() for f in np.fft.fftfreq(normalized_sales.size)]
power = np.abs(np.fft.fft(normalized_sales.ravel()))**2
list(zip(frequencies, power))[:len(power) // 2]
```




    [(Fraction(0, 1), 4.930380657631324e-32),
     (Fraction(1, 28), 11.81850804066758),
     (Fraction(1, 14), 3.062417712828277),
     (Fraction(3, 28), 3.6145035763808604),
     (Fraction(1, 7), 8.99248933467605),
     (Fraction(5, 28), 3.689054592513947),
     (Fraction(3, 14), 8.363267066546033),
     (Fraction(1, 4), 16.615944819859244),
     (Fraction(2, 7), 0.6736105397207641),
     (Fraction(9, 28), 6.846412421396464),
     (Fraction(5, 14), 14.279717692527928),
     (Fraction(11, 28), 17.951272090034657),
     (Fraction(3, 7), 4.608890497088776),
     (Fraction(13, 28), 6.579601542582696)]




```python
np.array([n for n in np.random.randint(1, 10, 100) if n %2 == 0])
```




    array([4, 2, 4, 2, 2, 4, 8, 4, 2, 8, 4, 2, 6, 6, 4, 6, 2, 2, 4, 8, 8, 2,
           8, 8, 8, 8, 8, 8, 2, 8, 8, 6, 4, 4, 4, 6, 2, 6])




```python
random_array = np.random.randint(1, 10, 100)
random_array[random_array % 2 == 0]
```




    array([4, 4, 6, 8, 8, 6, 8, 4, 4, 2, 8, 2, 2, 6, 2, 6, 4, 8, 6, 8, 4, 2,
           6, 6, 6, 4, 4, 4, 4, 8, 2, 8, 2, 4, 2, 4, 8, 6, 8])



Some of the functions we used above do not exist in standard Python and are provided to us by NumPy. Additionally we see that we can use the shape of an array to help us compute statistics on a subset of our data (e.g. mean number of coffees sold on Mondays). But one of the most powerful things we can do to explore data is to simply visualize it.

## Matplotlib

Matplotlib is the most popular Python plotting library. It allows us to visualize data quickly by providing a variety of types of graphs (e.g. bar, scatter, line, etc.). It also provides useful tools for arranging multiple images or image components within a figure, enabling us to build up more complex visualizations as we need to.

Let's visualize some data! In the next cells, we'll generate some data. For now we'll be focusing on how the graphs are produced rather than how the data is made.


```python
import matplotlib.pyplot as plt
```


```python
def gen_stock_price(days, initial_price):
    # stock price grows or shrinks linearly
    # not exceeding 10% per year (heuristic)
    trend = initial_price * (np.arange(days) * .1 / 365 * np.random.rand() * np.random.choice([1, -1]) + 1)
    # noise will be about 2%
    noise = .02 * np.random.randn(len(trend)) * trend
    return trend + noise

days = 365
initial_prices = [80, 70, 65]
for price in initial_prices:
    plt.plot(np.arange(-days, 0), gen_stock_price(days, price))
plt.title('Stock price history for last %d days' % days)
plt.xlabel('Time (days)')
plt.ylabel('Price (USD)')
plt.legend(['Company A', 'Company B', 'Company C'])
```




    <matplotlib.legend.Legend at 0x7fcabe0acd30>




![png](output_75_1.png)



```python
from scipy.stats import linregress

def gen_football_team(n_players, mean_shoe, mean_jersey):
    shoe_sizes = np.random.normal(size=n_players, loc=mean_shoe, scale=.15 * mean_shoe)
    jersey_sizes = mean_jersey / mean_shoe * shoe_sizes + np.random.normal(size=n_players, scale=.05 * mean_jersey)

    return shoe_sizes, jersey_sizes

shoes, jerseys = gen_football_team(16, 11, 100)

fig = plt.figure(figsize=(12, 6))
fig.suptitle('Football team equipment profile')

ax1 = plt.subplot(221)
ax1.hist(shoes)
ax1.set_xlabel('Shoe size')
ax1.set_ylabel('Counts')

ax2 = plt.subplot(223)
ax2.hist(jerseys)
ax2.set_xlabel('Chest size (cm)')
ax2.set_ylabel('Counts')

ax3 = plt.subplot(122)
ax3.scatter(shoes, jerseys, label='Data')
ax3.set_xlabel('Shoe size')
ax3.set_ylabel('Chest size (cm)')

fit_line = linregress(shoes, jerseys)
ax3.plot(shoes, fit_line[1] + fit_line[0] * shoes, 'r', label='Line of best fit')

handles, labels = ax3.get_legend_handles_labels()
ax3.legend(handles[::-1], labels[::-1])
```




    <matplotlib.legend.Legend at 0x7fcabdecf630>




![png](output_76_1.png)



```python
def gen_hourly_temps(days):
    ndays = len(days)
    seasonality = (-15 * np.cos((np.array(days) - 30) * 2.0 * np.pi / 365)).repeat(24) + 10
    solar = -3 * np.cos(np.arange(24 * ndays) * 2.0 * np.pi / 24)
    weather = np.interp(range(len(days) * 24), range(0, 24 * len(days), 24 * 2), 3 * np.random.randn(np.ceil(float(len(days)) / 2).astype(int)))
    noise = .5 * np.random.randn(24 * len(days))

    return seasonality + solar + weather + noise

days = np.arange(365)
hours = np.arange(days[0] * 24, (days[-1] + 1) * 24)
plt.plot(hours, gen_hourly_temps(days))
plt.title('Hourly temperatures')
plt.xlabel('Time (hours since Jan. 1)')
plt.ylabel('Temperature (C)')
```




    <matplotlib.text.Text at 0x7fcabd7ee710>




![png](output_77_1.png)


In the examples above we've made use of the ubiquitous `plot` command, `subplot` for arranging multiple plots in one image, and `hist` for creating histograms. We've also used both the "state machine" (i.e. using a sequence of `plt.method` commands) and "object-oriented" (i.e. creating figure objects and mutating them) plotting paradigms. The Matplotlib package is very flexible and the possibilities for visualizing data are mostly limited by imagination. A great way to explore Matplotlib and other data visualization packages is by consulting their [gallery pages](https://matplotlib.org/gallery.html).

# Pandas

NumPy is useful for handling data as it lets us efficiently apply functions to whole data sets or select pieces of them. However, it can be difficult to keep track of related data that might be stored in different arrays, or the meaning of data stored in different rows or columns of the same array.

For example, in the previous section we had a 1-dimensional array for shoe sizes, and another 1-dimensional array for jersey sizes. If we wanted to look up the shoe and jersey size for a particular player, we'd have to remember his position in each array.

Alternatively, we could combine the two 1-dimensional arrays to make a 2-dimensional array with `n_players` rows and two columns (one for shoe size, one for jersey size). But once we combine the data, we now have to remember which column is shoe size and which column is jersey size.

The Pandas package introduces a very powerful tool for working with data in Python: the DataFrame. A DataFrame is a table. Each column represents a different type of data (sometimes called a **field**). The columns are named, so I could have a column called `'shoe_size'` and a column called `'jersey_size'`. I don't have to remember which column is which, because I can refer to them by name. Each row represents a different **record** or **entity** (e.g. player). I can also name the rows, so instead of remembering which row in my array corresponds with Ronaldinho, I can name the row 'Ronaldinho' and look up his shoe size and jersey size by name.


```python
import pandas as pd

players = ['Ronaldinho', 'Pele', 'Lionel Messi', 'Zinedine Zidane', 'Didier Drogba', 'Ronaldo', 'Yaya Toure', 
           'Frank Rijkaard', 'Diego Maradona', 'Mohamed Aboutrika', "Samuel Eto'o", 'George Best', 'George Weah', 
           'Roberto Donadoni']
shoes, jerseys = gen_football_team(len(players), 10, 100)

df = pd.DataFrame({'shoe_size': shoes, 'jersey_size': jerseys}, index = players)

df
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>jersey_size</th>
      <th>shoe_size</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Ronaldinho</th>
      <td>114.631879</td>
      <td>11.742255</td>
    </tr>
    <tr>
      <th>Pele</th>
      <td>102.198742</td>
      <td>9.722685</td>
    </tr>
    <tr>
      <th>Lionel Messi</th>
      <td>80.053963</td>
      <td>7.741378</td>
    </tr>
    <tr>
      <th>Zinedine Zidane</th>
      <td>108.756991</td>
      <td>11.259917</td>
    </tr>
    <tr>
      <th>Didier Drogba</th>
      <td>125.531000</td>
      <td>12.528553</td>
    </tr>
    <tr>
      <th>Ronaldo</th>
      <td>83.547827</td>
      <td>9.030637</td>
    </tr>
    <tr>
      <th>Yaya Toure</th>
      <td>96.251138</td>
      <td>9.282169</td>
    </tr>
    <tr>
      <th>Frank Rijkaard</th>
      <td>106.423742</td>
      <td>10.773491</td>
    </tr>
    <tr>
      <th>Diego Maradona</th>
      <td>122.149552</td>
      <td>12.432811</td>
    </tr>
    <tr>
      <th>Mohamed Aboutrika</th>
      <td>92.038115</td>
      <td>9.220249</td>
    </tr>
    <tr>
      <th>Samuel Eto'o</th>
      <td>80.214792</td>
      <td>8.001325</td>
    </tr>
    <tr>
      <th>George Best</th>
      <td>113.945929</td>
      <td>10.947128</td>
    </tr>
    <tr>
      <th>George Weah</th>
      <td>114.941474</td>
      <td>11.198602</td>
    </tr>
    <tr>
      <th>Roberto Donadoni</th>
      <td>99.309925</td>
      <td>10.009197</td>
    </tr>
  </tbody>
</table>
</div>




```python
# we can also make a dataframe using zip

df = pd.DataFrame(list(zip(shoes, jerseys)), columns = ['shoe_size', 'jersey_size'], index = players)

df
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>shoe_size</th>
      <th>jersey_size</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Ronaldinho</th>
      <td>11.742255</td>
      <td>114.631879</td>
    </tr>
    <tr>
      <th>Pele</th>
      <td>9.722685</td>
      <td>102.198742</td>
    </tr>
    <tr>
      <th>Lionel Messi</th>
      <td>7.741378</td>
      <td>80.053963</td>
    </tr>
    <tr>
      <th>Zinedine Zidane</th>
      <td>11.259917</td>
      <td>108.756991</td>
    </tr>
    <tr>
      <th>Didier Drogba</th>
      <td>12.528553</td>
      <td>125.531000</td>
    </tr>
    <tr>
      <th>Ronaldo</th>
      <td>9.030637</td>
      <td>83.547827</td>
    </tr>
    <tr>
      <th>Yaya Toure</th>
      <td>9.282169</td>
      <td>96.251138</td>
    </tr>
    <tr>
      <th>Frank Rijkaard</th>
      <td>10.773491</td>
      <td>106.423742</td>
    </tr>
    <tr>
      <th>Diego Maradona</th>
      <td>12.432811</td>
      <td>122.149552</td>
    </tr>
    <tr>
      <th>Mohamed Aboutrika</th>
      <td>9.220249</td>
      <td>92.038115</td>
    </tr>
    <tr>
      <th>Samuel Eto'o</th>
      <td>8.001325</td>
      <td>80.214792</td>
    </tr>
    <tr>
      <th>George Best</th>
      <td>10.947128</td>
      <td>113.945929</td>
    </tr>
    <tr>
      <th>George Weah</th>
      <td>11.198602</td>
      <td>114.941474</td>
    </tr>
    <tr>
      <th>Roberto Donadoni</th>
      <td>10.009197</td>
      <td>99.309925</td>
    </tr>
  </tbody>
</table>
</div>



The DataFrame has similarities to both a `dict` and a NumPy `ndarray`. For example, we can retrieve a column from the DataFrame by using its name, just like we would retrieve an item from a `dict` using its key.


```python
print(df['shoe_size'])
```

    Ronaldinho           11.742255
    Pele                  9.722685
    Lionel Messi          7.741378
    Zinedine Zidane      11.259917
    Didier Drogba        12.528553
    Ronaldo               9.030637
    Yaya Toure            9.282169
    Frank Rijkaard       10.773491
    Diego Maradona       12.432811
    Mohamed Aboutrika     9.220249
    Samuel Eto'o          8.001325
    George Best          10.947128
    George Weah          11.198602
    Roberto Donadoni     10.009197
    Name: shoe_size, dtype: float64


And we can easily apply functions to the DataFrame, just like we would with a NumPy array.


```python
print(np.log(df))
```

                       shoe_size  jersey_size
    Ronaldinho          2.463194     4.741726
    Pele                2.274462     4.626919
    Lionel Messi        2.046580     4.382701
    Zinedine Zidane     2.421249     4.689116
    Didier Drogba       2.528010     4.832553
    Ronaldo             2.200623     4.425419
    Yaya Toure          2.228095     4.566961
    Frank Rijkaard      2.377089     4.667429
    Diego Maradona      2.520339     4.805246
    Mohamed Aboutrika   2.221402     4.522203
    Samuel Eto'o        2.079607     4.384708
    George Best         2.393077     4.735724
    George Weah         2.415789     4.744423
    Roberto Donadoni    2.303504     4.598246



```python
df.mean()
```




    shoe_size       10.277885
    jersey_size    102.856791
    dtype: float64



We'll explore applying functions and analyzing data in a DataFrame in more depth later on. First we need to know how to retrieve, add, and remove data from a DataFrame.

We've already seen how to retrieve a column, what about retrieving a row? The most flexible syntax is to use the DataFrame's `loc` method.


```python
print(df.loc['Ronaldo'])
```

    shoe_size       9.030637
    jersey_size    83.547827
    Name: Ronaldo, dtype: float64



```python
print(df.loc[['Ronaldo', 'George Best'], 'shoe_size'])
```

    Ronaldo         9.030637
    George Best    10.947128
    Name: shoe_size, dtype: float64



```python
# can also select position-based slices of data
print(df.loc['Ronaldo':'George Best', 'shoe_size'])
```

    Ronaldo               9.030637
    Yaya Toure            9.282169
    Frank Rijkaard       10.773491
    Diego Maradona       12.432811
    Mohamed Aboutrika     9.220249
    Samuel Eto'o          8.001325
    George Best          10.947128
    Name: shoe_size, dtype: float64



```python
# for position-based indexing, we will typically use iloc
print(df.iloc[:5])
```

                     shoe_size  jersey_size
    Ronaldinho       11.742255   114.631879
    Pele              9.722685   102.198742
    Lionel Messi      7.741378    80.053963
    Zinedine Zidane  11.259917   108.756991
    Didier Drogba    12.528553   125.531000



```python
print(df.iloc[2:4, 0])
```

    Lionel Messi        7.741378
    Zinedine Zidane    11.259917
    Name: shoe_size, dtype: float64



```python
# to see just the top of the DataFrame, use head
df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>shoe_size</th>
      <th>jersey_size</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Ronaldinho</th>
      <td>11.742255</td>
      <td>114.631879</td>
    </tr>
    <tr>
      <th>Pele</th>
      <td>9.722685</td>
      <td>102.198742</td>
    </tr>
    <tr>
      <th>Lionel Messi</th>
      <td>7.741378</td>
      <td>80.053963</td>
    </tr>
    <tr>
      <th>Zinedine Zidane</th>
      <td>11.259917</td>
      <td>108.756991</td>
    </tr>
    <tr>
      <th>Didier Drogba</th>
      <td>12.528553</td>
      <td>125.531000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# of for the bottom use tail
df.tail()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>shoe_size</th>
      <th>jersey_size</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Mohamed Aboutrika</th>
      <td>9.220249</td>
      <td>92.038115</td>
    </tr>
    <tr>
      <th>Samuel Eto'o</th>
      <td>8.001325</td>
      <td>80.214792</td>
    </tr>
    <tr>
      <th>George Best</th>
      <td>10.947128</td>
      <td>113.945929</td>
    </tr>
    <tr>
      <th>George Weah</th>
      <td>11.198602</td>
      <td>114.941474</td>
    </tr>
    <tr>
      <th>Roberto Donadoni</th>
      <td>10.009197</td>
      <td>99.309925</td>
    </tr>
  </tbody>
</table>
</div>



Just as with a `dict`, we can add data to our DataFrame by simply using the same syntax as we would use to retrieve data, but matching it with an assignment.


```python
# adding a new column
df['position'] = np.random.choice(['goaltender', 'defense', 'midfield', 'attack'], size=len(df))
df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>shoe_size</th>
      <th>jersey_size</th>
      <th>position</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Ronaldinho</th>
      <td>11.742255</td>
      <td>114.631879</td>
      <td>attack</td>
    </tr>
    <tr>
      <th>Pele</th>
      <td>9.722685</td>
      <td>102.198742</td>
      <td>defense</td>
    </tr>
    <tr>
      <th>Lionel Messi</th>
      <td>7.741378</td>
      <td>80.053963</td>
      <td>attack</td>
    </tr>
    <tr>
      <th>Zinedine Zidane</th>
      <td>11.259917</td>
      <td>108.756991</td>
      <td>attack</td>
    </tr>
    <tr>
      <th>Didier Drogba</th>
      <td>12.528553</td>
      <td>125.531000</td>
      <td>goaltender</td>
    </tr>
  </tbody>
</table>
</div>




```python
# adding a new row
df.loc['Dylan'] = {'jersey_size': 91, 'shoe_size': 9, 'position': 'midfield'}
df.loc['Dylan']
```




    shoe_size             9
    jersey_size          91
    position       midfield
    Name: Dylan, dtype: object



To delete data, we can use the DataFrame's `drop` method.


```python
df.drop('Dylan')
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>shoe_size</th>
      <th>jersey_size</th>
      <th>position</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Ronaldinho</th>
      <td>11.742255</td>
      <td>114.631879</td>
      <td>attack</td>
    </tr>
    <tr>
      <th>Pele</th>
      <td>9.722685</td>
      <td>102.198742</td>
      <td>defense</td>
    </tr>
    <tr>
      <th>Lionel Messi</th>
      <td>7.741378</td>
      <td>80.053963</td>
      <td>attack</td>
    </tr>
    <tr>
      <th>Zinedine Zidane</th>
      <td>11.259917</td>
      <td>108.756991</td>
      <td>attack</td>
    </tr>
    <tr>
      <th>Didier Drogba</th>
      <td>12.528553</td>
      <td>125.531000</td>
      <td>goaltender</td>
    </tr>
    <tr>
      <th>Ronaldo</th>
      <td>9.030637</td>
      <td>83.547827</td>
      <td>defense</td>
    </tr>
    <tr>
      <th>Yaya Toure</th>
      <td>9.282169</td>
      <td>96.251138</td>
      <td>attack</td>
    </tr>
    <tr>
      <th>Frank Rijkaard</th>
      <td>10.773491</td>
      <td>106.423742</td>
      <td>goaltender</td>
    </tr>
    <tr>
      <th>Diego Maradona</th>
      <td>12.432811</td>
      <td>122.149552</td>
      <td>midfield</td>
    </tr>
    <tr>
      <th>Mohamed Aboutrika</th>
      <td>9.220249</td>
      <td>92.038115</td>
      <td>attack</td>
    </tr>
    <tr>
      <th>Samuel Eto'o</th>
      <td>8.001325</td>
      <td>80.214792</td>
      <td>defense</td>
    </tr>
    <tr>
      <th>George Best</th>
      <td>10.947128</td>
      <td>113.945929</td>
      <td>midfield</td>
    </tr>
    <tr>
      <th>George Weah</th>
      <td>11.198602</td>
      <td>114.941474</td>
      <td>attack</td>
    </tr>
    <tr>
      <th>Roberto Donadoni</th>
      <td>10.009197</td>
      <td>99.309925</td>
      <td>attack</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.drop('position', axis=1)
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>shoe_size</th>
      <th>jersey_size</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Ronaldinho</th>
      <td>11.742255</td>
      <td>114.631879</td>
    </tr>
    <tr>
      <th>Pele</th>
      <td>9.722685</td>
      <td>102.198742</td>
    </tr>
    <tr>
      <th>Lionel Messi</th>
      <td>7.741378</td>
      <td>80.053963</td>
    </tr>
    <tr>
      <th>Zinedine Zidane</th>
      <td>11.259917</td>
      <td>108.756991</td>
    </tr>
    <tr>
      <th>Didier Drogba</th>
      <td>12.528553</td>
      <td>125.531000</td>
    </tr>
    <tr>
      <th>Ronaldo</th>
      <td>9.030637</td>
      <td>83.547827</td>
    </tr>
    <tr>
      <th>Yaya Toure</th>
      <td>9.282169</td>
      <td>96.251138</td>
    </tr>
    <tr>
      <th>Frank Rijkaard</th>
      <td>10.773491</td>
      <td>106.423742</td>
    </tr>
    <tr>
      <th>Diego Maradona</th>
      <td>12.432811</td>
      <td>122.149552</td>
    </tr>
    <tr>
      <th>Mohamed Aboutrika</th>
      <td>9.220249</td>
      <td>92.038115</td>
    </tr>
    <tr>
      <th>Samuel Eto'o</th>
      <td>8.001325</td>
      <td>80.214792</td>
    </tr>
    <tr>
      <th>George Best</th>
      <td>10.947128</td>
      <td>113.945929</td>
    </tr>
    <tr>
      <th>George Weah</th>
      <td>11.198602</td>
      <td>114.941474</td>
    </tr>
    <tr>
      <th>Roberto Donadoni</th>
      <td>10.009197</td>
      <td>99.309925</td>
    </tr>
    <tr>
      <th>Dylan</th>
      <td>9.000000</td>
      <td>91.000000</td>
    </tr>
  </tbody>
</table>
</div>



Notice when we executed `df.drop('position', axis=1)`, there was an entry for `Dylan` even though we had just executed `df.drop('Dylan')`. We have to be careful when using `drop`; many DataFrame functions return a _copy_ of the DataFrame. In order to make the change permanent, we either need to reassign `df` to the copy returned by `df.drop()` or we have to use the keyword `inplace`.


```python
df = df.drop('Dylan')
print(df)
```

                       shoe_size  jersey_size    position
    Ronaldinho         11.742255   114.631879      attack
    Pele                9.722685   102.198742     defense
    Lionel Messi        7.741378    80.053963      attack
    Zinedine Zidane    11.259917   108.756991      attack
    Didier Drogba      12.528553   125.531000  goaltender
    Ronaldo             9.030637    83.547827     defense
    Yaya Toure          9.282169    96.251138      attack
    Frank Rijkaard     10.773491   106.423742  goaltender
    Diego Maradona     12.432811   122.149552    midfield
    Mohamed Aboutrika   9.220249    92.038115      attack
    Samuel Eto'o        8.001325    80.214792     defense
    George Best        10.947128   113.945929    midfield
    George Weah        11.198602   114.941474      attack
    Roberto Donadoni   10.009197    99.309925      attack



```python
df.drop('position', axis=1, inplace=True)
print(df)
```

                       shoe_size  jersey_size
    Ronaldinho         11.742255   114.631879
    Pele                9.722685   102.198742
    Lionel Messi        7.741378    80.053963
    Zinedine Zidane    11.259917   108.756991
    Didier Drogba      12.528553   125.531000
    Ronaldo             9.030637    83.547827
    Yaya Toure          9.282169    96.251138
    Frank Rijkaard     10.773491   106.423742
    Diego Maradona     12.432811   122.149552
    Mohamed Aboutrika   9.220249    92.038115
    Samuel Eto'o        8.001325    80.214792
    George Best        10.947128   113.945929
    George Weah        11.198602   114.941474
    Roberto Donadoni   10.009197    99.309925


We'll explore Pandas in much more detail later in the course, since it has many powerful tools for data analysis. However, even with these tools you can already start to discover patterns in data and draw interesting conclusions.

*Copyright &copy; 2017 The Data Incubator.  All rights reserved.*
