

```python
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
```


```python
from static_grader import grader
```

# DW Miniproject
## Introduction

The objective of this miniproject is to exercise your ability to wrangle tabular data set and aggregate large data sets into meaningful summary statistics. We will be working with the same medical data used in the `pw` miniproject, but will be leveraging the power of Pandas to more efficiently represent and act on our data.

## Downloading the data

We first need to download the data we'll be using from Amazon S3:


```python
!mkdir dw-data
!wget http://dataincubator-wqu.s3.amazonaws.com/dwdata/201701scripts_sample.csv.gz -nc -P ./dw-data/
!wget http://dataincubator-wqu.s3.amazonaws.com/dwdata/201606scripts_sample.csv.gz -nc -P ./dw-data/
!wget http://dataincubator-wqu.s3.amazonaws.com/dwdata/practices.csv.gz -nc -P ./dw-data/
!wget http://dataincubator-wqu.s3.amazonaws.com/dwdata/chem.csv.gz -nc -P ./dw-data/
```

    mkdir: cannot create directory ‘dw-data’: File exists
    File ‘./dw-data/201701scripts_sample.csv.gz’ already there; not retrieving.
    
    File ‘./dw-data/201606scripts_sample.csv.gz’ already there; not retrieving.
    
    File ‘./dw-data/practices.csv.gz’ already there; not retrieving.
    
    File ‘./dw-data/chem.csv.gz’ already there; not retrieving.
    


## Loading the data

Similar to the `PW` miniproject, the first step is to read in the data. The data files are stored as compressed CSV files. You can load the data into a Pandas DataFrame by making use of the `gzip` package to decompress the files and Panda's `read_csv` methods to parse the data into a DataFrame. You may want to check the Pandas documentation for parsing [CSV](http://pandas.pydata.org/pandas-docs/stable/generated/pandas.read_csv.html) files for reference.

For a description of the data set please, refer to the [PW miniproject](./pw.ipynb). **Note that all questions make use of the 2017 data only, except for Question 5 which makes use of both the 2017 and 2016 data.**


```python
import pandas as pd
import numpy as np
import gzip
```


```python
!ls
```

    dw-Copy1.ipynb	dw-data   in-Copy1.ipynb  pw-Copy1.ipynb  pw.ipynb
    dw-Copy2.ipynb	dw.ipynb  in.ipynb	  pw-data



```python
# load the 2017 data
scripts = pd.read_csv('dw-data/201701scripts_sample.csv.gz')
scripts.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>bnf_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>nic</th>
      <th>act_cost</th>
      <th>quantity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>N85639</td>
      <td>0106020C0</td>
      <td>Bisacodyl_Tab E/C 5mg</td>
      <td>1</td>
      <td>0.39</td>
      <td>0.47</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1</th>
      <td>N85639</td>
      <td>0106040M0</td>
      <td>Movicol Plain_Paed Pdr Sach 6.9g</td>
      <td>1</td>
      <td>4.38</td>
      <td>4.07</td>
      <td>30</td>
    </tr>
    <tr>
      <th>2</th>
      <td>N85639</td>
      <td>0301011R0</td>
      <td>Salbutamol_Inha 100mcg (200 D) CFF</td>
      <td>1</td>
      <td>1.50</td>
      <td>1.40</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>N85639</td>
      <td>0304010G0</td>
      <td>Chlorphenamine Mal_Oral Soln 2mg/5ml</td>
      <td>1</td>
      <td>2.62</td>
      <td>2.44</td>
      <td>150</td>
    </tr>
    <tr>
      <th>4</th>
      <td>N85639</td>
      <td>0401020K0</td>
      <td>Diazepam_Tab 2mg</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.26</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
col_names=[ 'code', 'name', 'addr_1', 'addr_2', 'borough', 'village', 'post_code']
practices = pd.read_csv('dw-data/practices.csv.gz', names=col_names)
practices.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>code</th>
      <th>name</th>
      <th>addr_1</th>
      <th>addr_2</th>
      <th>borough</th>
      <th>village</th>
      <th>post_code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A81001</td>
      <td>THE DENSHAM SURGERY</td>
      <td>THE HEALTH CENTRE</td>
      <td>LAWSON STREET</td>
      <td>STOCKTON ON TEES</td>
      <td>CLEVELAND</td>
      <td>TS18 1HU</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A81002</td>
      <td>QUEENS PARK MEDICAL CENTRE</td>
      <td>QUEENS PARK MEDICAL CTR</td>
      <td>FARRER STREET</td>
      <td>STOCKTON ON TEES</td>
      <td>CLEVELAND</td>
      <td>TS18 2AW</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A81003</td>
      <td>VICTORIA MEDICAL PRACTICE</td>
      <td>THE HEALTH CENTRE</td>
      <td>VICTORIA ROAD</td>
      <td>HARTLEPOOL</td>
      <td>CLEVELAND</td>
      <td>TS26 8DB</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A81004</td>
      <td>WOODLANDS ROAD SURGERY</td>
      <td>6 WOODLANDS ROAD</td>
      <td>NaN</td>
      <td>MIDDLESBROUGH</td>
      <td>CLEVELAND</td>
      <td>TS1 3BE</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A81005</td>
      <td>SPRINGWOOD SURGERY</td>
      <td>SPRINGWOOD SURGERY</td>
      <td>RECTORY LANE</td>
      <td>GUISBOROUGH</td>
      <td>NaN</td>
      <td>TS14 7DJ</td>
    </tr>
  </tbody>
</table>
</div>




```python
chem = pd.read_csv('dw-data/chem.csv.gz')
chem.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CHEM SUB</th>
      <th>NAME</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0101010A0</td>
      <td>Alexitol Sodium</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0101010B0</td>
      <td>Almasilate</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0101010C0</td>
      <td>Aluminium Hydroxide</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0101010D0</td>
      <td>Aluminium Hydroxide With Magnesium</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0101010E0</td>
      <td>Hydrotalcite</td>
    </tr>
  </tbody>
</table>
</div>



Now that we've loaded in the data, let's first replicate our results from the `PW` miniproject. Note that we are now working with a larger data set so the answers will be different than in the `PW` miniproject even if the analysis is the same.

## Question 1: summary_statistics

In the `PW` miniproject we first calculated the total, mean, standard deviation, and quartile statistics of the `'items'`, `'quantity'`', `'nic'`, and `'act_cost'` fields. To do this we had to write some functions to calculate the statistics and apply the functions to our data structure. The DataFrame has a `describe` method that will calculate most (not all) of these things for us.

Submit the summary statistics to the grader as a list of tuples: [('act_cost', (total, mean, std, q25, median, q75)), ...]


```python
# target = total, mean, standard deviation, quartile statistics ()
stats = scripts.describe()
stats
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>items</th>
      <th>nic</th>
      <th>act_cost</th>
      <th>quantity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>973193.000000</td>
      <td>973193.000000</td>
      <td>973193.000000</td>
      <td>973193.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>9.133136</td>
      <td>73.058915</td>
      <td>67.986613</td>
      <td>741.329835</td>
    </tr>
    <tr>
      <th>std</th>
      <td>29.204198</td>
      <td>188.070257</td>
      <td>174.401703</td>
      <td>3665.426958</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.040000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.000000</td>
      <td>7.800000</td>
      <td>7.330000</td>
      <td>28.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2.000000</td>
      <td>22.640000</td>
      <td>21.220000</td>
      <td>100.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>6.000000</td>
      <td>65.000000</td>
      <td>60.670000</td>
      <td>350.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2384.000000</td>
      <td>16320.000000</td>
      <td>15108.320000</td>
      <td>577720.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
stats['items']['mean']
```




    9.133135976111625




```python
fields = ['items', 'quantity', 'nic', 'act_cost']
print(sum(scripts['items']))
print(sum(scripts['quantity']))
print(sum(scripts['nic']))
print(sum(scripts['act_cost']))
```

    8888304
    721457006
    71100424.84000827
    66164096.11999956



```python
# order of stats ('act_cost', (total, mean, std, q25, median, q75)
# summary_stats = [('items', (0,)* 6), ('quantity', (0,) * 6), ('nic', (0,) * 6), ('act_cost', (0,) * 6)]

fields = ['items', 'quantity', 'nic', 'act_cost']
summary_stats = []

for field in fields:
    stats[field]
    field_stats = (field,
                   (sum(scripts[field]),
                    stats[field]['mean'],
                    stats[field]['std'],
                    stats[field]['25%'],
                    stats[field]['50%'],
                    stats[field]['75%']))
    summary_stats.append(field_stats)
    

```


```python
# order of stats ('act_cost', (total, mean, std, q25, median, q75)
fields = ['items', 'quantity', 'nic', 'act_cost']
summary_stats = [
    (field, (sum(scripts[field]),
             stats[field]['mean'],
             stats[field]['std'],
             stats[field]['25%'],
             stats[field]['50%'],
             stats[field]['75%']))
    for field in fields]
    

```


```python
grader.score.dw__summary_statistics(summary_stats)
```

    ==================
    Your score:  1.0
    ==================


## Question 2: most_common_item

We can also easily compute summary statistics on groups within the data. In the `pw` miniproject we had to explicitly construct the groups based on the values of a particular field. Pandas will handle that for us via the `groupby` method. This process is [detailed in the Pandas documentation](https://pandas.pydata.org/pandas-docs/stable/groupby.html).

Use `groupby` to calculate the total number of items dispensed for each `'bnf_name'`. Find the item with the highest total and return the result as `[(bnf_name, total)]`.


```python
total_by_bnf = scripts.groupby('bnf_name').items.sum()

max_item = ['', 0]

group_keys = total_by_bnf.index

for bnf_name in group_keys:
    if total_by_bnf[bnf_name] > max_item[1]:
        max_item[0] = bnf_name
        max_item[1] = total_by_bnf[bnf_name]
        
max_item
```




    ['Omeprazole_Cap E/C 20mg', 218583]




```python
total_by_bnf.head()
```




    bnf_name
    365 Film 10cm x 12cm VP Adh Film Dress      2
    365 Non Adherent 10cm x 10cm Pfa Plas Fa    3
    365 Non Adherent 10cm x 20cm Pfa Plas Fa    1
    365 Non Woven Island 8cm x 10cm Adh Dres    1
    365 Transpt Island 5cm x 7.2cm VP Adh Fi    2
    Name: items, dtype: int64




```python
# total_by_bnf.index
total_by_bnf.keys()
```




    Index(['365 Film 10cm x 12cm VP Adh Film Dress',
           '365 Non Adherent 10cm x 10cm Pfa Plas Fa',
           '365 Non Adherent 10cm x 20cm Pfa Plas Fa',
           '365 Non Woven Island 8cm x 10cm Adh Dres',
           '365 Transpt Island 5cm x 7.2cm VP Adh Fi',
           '365 Transpt Island 8.5cm x 15.5cm VP Adh',
           '3M Micropore Silicone 2.5cm x 5m Surg Ad',
           '3M Micropore Silicone 5cm x 5m Surg Adh',
           '3m Health Care_Cavilon Durable Barrier C',
           '3m Health Care_Cavilon No Sting 1ml Barr',
           ...
           'kliniderm Foam Slc Sacrum Border 18cmx18',
           'kliniderm superabsorbent 10cm x 10cm Pfa',
           'kliniderm superabsorbent 10cm x 15cm Pfa',
           'kliniderm superabsorbent 20cm x 20cm Pfa',
           'kliniderm superabsorbent 20cm x 30cm Pfa',
           'nSpire PiKo-1 Stnd Range Peak Flow Meter',
           'nSpire Pocket Peak Low Range Peak Flow M',
           'nSpire Pocket Peak Stnd Range Peak Flow',
           'oraNurse_Toothpaste Orig (1450ppm)', 'palmdoc (Reagent)_Strips'],
          dtype='object', name='bnf_name', length=13471)




```python
most_common_item = [tuple(max_item)]
most_common_item
```




    [('Omeprazole_Cap E/C 20mg', 218583)]




```python
most_common_item = [(key, total_by_bnf[key]) for key in total_by_bnf.keys() if total_by_bnf[key] == total_by_bnf.max()]
```


```python
most_common_item
```




    [('Omeprazole_Cap E/C 20mg', 218583)]




```python
max_item = total_by_bnf.idxmax()
most_common_item = [(max_item, total_by_bnf[max_item])]

```


```python
print(most_common_item)
```

    [('Omeprazole_Cap E/C 20mg', 218583)]



```python
grader.score.dw__most_common_item(most_common_item)
```

    ==================
    Your score:  1.0
    ==================


## Question 3: items_by_region

Now let's find the most common item by post code. The post code information is in the `practices` DataFrame, and we'll need to `merge` it into the `scripts` DataFrame. Pandas provides [extensive documentation](https://pandas.pydata.org/pandas-docs/stable/merging.html) with diagrammed examples on different methods and approaches for joining data. The `merge` method is only one of many possible options.

Return your results as a list of tuples `(post code, item name, amount dispensed as % of total)`. Sort your results ascending alphabetically by post code and take only results from the first 100 post codes.

**NOTE:** Some practices have multiple postal codes associated with them. Use the alphabetically first postal code. Note some postal codes may have multiple `'bnf_name'` with the same prescription rate for the maximum. In this case, take the alphabetically first `'bnf_name'` (as in the PW miniproject).


```python
practice_codes = practices['code']
print(practice_codes.shape)
print(practice_codes.head())

```

    (12020,)
    0    A81001
    1    A81002
    2    A81003
    3    A81004
    4    A81005
    Name: code, dtype: object



```python
unique_practices = practices.sort_values('post_code').groupby('code').first().reset_index()
print(unique_practices.shape)
unique_practices.head()
```

    (10843, 7)





<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>code</th>
      <th>name</th>
      <th>addr_1</th>
      <th>addr_2</th>
      <th>borough</th>
      <th>village</th>
      <th>post_code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A81001</td>
      <td>THE DENSHAM SURGERY</td>
      <td>THE HEALTH CENTRE</td>
      <td>LAWSON STREET</td>
      <td>STOCKTON ON TEES</td>
      <td>CLEVELAND</td>
      <td>TS18 1HU</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A81002</td>
      <td>QUEENS PARK MEDICAL CENTRE</td>
      <td>QUEENS PARK MEDICAL CTR</td>
      <td>FARRER STREET</td>
      <td>STOCKTON ON TEES</td>
      <td>CLEVELAND</td>
      <td>TS18 2AW</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A81003</td>
      <td>VICTORIA MEDICAL PRACTICE</td>
      <td>MCKENZIE HOUSE</td>
      <td>17 KENDAL ROAD</td>
      <td>HARTLEPOOL</td>
      <td>CLEVELAND</td>
      <td>TS25 1QU</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A81004</td>
      <td>WOODLANDS ROAD SURGERY</td>
      <td>6 WOODLANDS ROAD</td>
      <td>ACKLAM</td>
      <td>MIDDLESBROUGH</td>
      <td>CLEVELAND</td>
      <td>TS1 3BE</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A81005</td>
      <td>SPRINGWOOD SURGERY</td>
      <td>SPRINGWOOD SURGERY</td>
      <td>RECTORY LANE</td>
      <td>GUISBOROUGH</td>
      <td>NaN</td>
      <td>TS14 7DJ</td>
    </tr>
  </tbody>
</table>
</div>




```python
joined = scripts.merge(unique_practices[['code', 'post_code']], how='right', left_on='practice', right_on='code')
```


```python
joined.tail()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>bnf_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>nic</th>
      <th>act_cost</th>
      <th>quantity</th>
      <th>code</th>
      <th>post_code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>983175</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Y05758</td>
      <td>WN8 6LJ</td>
    </tr>
    <tr>
      <th>983176</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Y05762</td>
      <td>SW20 8DA</td>
    </tr>
    <tr>
      <th>983177</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Y05763</td>
      <td>CB6 1DN</td>
    </tr>
    <tr>
      <th>983178</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Y05764</td>
      <td>PE11 3PB</td>
    </tr>
    <tr>
      <th>983179</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Y05771</td>
      <td>HA1 3UJ</td>
    </tr>
  </tbody>
</table>
</div>




```python
joined.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>bnf_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>nic</th>
      <th>act_cost</th>
      <th>quantity</th>
      <th>code</th>
      <th>post_code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>N85639</td>
      <td>0106020C0</td>
      <td>Bisacodyl_Tab E/C 5mg</td>
      <td>1.0</td>
      <td>0.39</td>
      <td>0.47</td>
      <td>12.0</td>
      <td>N85639</td>
      <td>CH44 5UF</td>
    </tr>
    <tr>
      <th>1</th>
      <td>N85639</td>
      <td>0106040M0</td>
      <td>Movicol Plain_Paed Pdr Sach 6.9g</td>
      <td>1.0</td>
      <td>4.38</td>
      <td>4.07</td>
      <td>30.0</td>
      <td>N85639</td>
      <td>CH44 5UF</td>
    </tr>
    <tr>
      <th>2</th>
      <td>N85639</td>
      <td>0301011R0</td>
      <td>Salbutamol_Inha 100mcg (200 D) CFF</td>
      <td>1.0</td>
      <td>1.50</td>
      <td>1.40</td>
      <td>1.0</td>
      <td>N85639</td>
      <td>CH44 5UF</td>
    </tr>
    <tr>
      <th>3</th>
      <td>N85639</td>
      <td>0304010G0</td>
      <td>Chlorphenamine Mal_Oral Soln 2mg/5ml</td>
      <td>1.0</td>
      <td>2.62</td>
      <td>2.44</td>
      <td>150.0</td>
      <td>N85639</td>
      <td>CH44 5UF</td>
    </tr>
    <tr>
      <th>4</th>
      <td>N85639</td>
      <td>0401020K0</td>
      <td>Diazepam_Tab 2mg</td>
      <td>1.0</td>
      <td>0.16</td>
      <td>0.26</td>
      <td>6.0</td>
      <td>N85639</td>
      <td>CH44 5UF</td>
    </tr>
  </tbody>
</table>
</div>




```python
 total_item_by_postal = joined.groupby(['post_code'])['items'].sum()  #['items'].sum().reset_index())
total_item_by_postal.shape
```




    (8137,)




```python
total_item_by_postal_with_null = total_item_by_postal[total_item_by_postal.isnull()]
total_item_by_postal_with_null.shape
```




    (7878,)




```python
total_item_by_postal = total_item_by_postal[total_item_by_postal.notnull()]
total_item_by_postal.shape
```




    (259,)




```python
total_item_by_postal[total_item_by_postal.isnull()].shape

```




    (0,)




```python
print(total_item_by_postal.min())
print(total_item_by_postal.max())
total_item_by_postal.reset_index().head()
```

    5379.0
    112283.0





<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post_code</th>
      <th>items</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>B11 4BW</td>
      <td>22731.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>B12 9LP</td>
      <td>17073.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>B18 7AL</td>
      <td>20508.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>B21 9RY</td>
      <td>31027.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>B23 6DJ</td>
      <td>28011.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
total_item_by_postal.idxmax()
```




    'SK11 6JL'




```python
total_by_bnf_post = (joined.groupby(['post_code', 'bnf_name'])['items'].sum().reset_index())
```


```python
total_by_bnf_post.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post_code</th>
      <th>bnf_name</th>
      <th>items</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>B11 4BW</td>
      <td>3m Health Care_Cavilon Durable Barrier C</td>
      <td>7.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>B11 4BW</td>
      <td>3m Health Care_Cavilon No Sting Barrier</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>B11 4BW</td>
      <td>Abasaglar KwikPen_100u/ml 3ml Pf Pen</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>B11 4BW</td>
      <td>Abidec_Dps</td>
      <td>63.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>B11 4BW</td>
      <td>Able Spacer + Sml/Med Mask</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
postal_total = total_by_bnf_post.groupby('post_code')['items'].sum()
postal_total.head()
```




    post_code
    B11 4BW    22731.0
    B12 9LP    17073.0
    B18 7AL    20508.0
    B21 9RY    31027.0
    B23 6DJ    28011.0
    Name: items, dtype: float64




```python
total_by_bnf_post['proportion'] = [
    item/postal_total[post_code]
    for post_code, item in 
    zip(total_by_bnf_post['post_code'],
        total_by_bnf_post['items'])
]



```


```python
max_mask = total_by_bnf_post.groupby('post_code')['items'].idxmax()

max_by_bnf_post = total_by_bnf_post.loc[max_mask]

```


```python
max_by_bnf_post.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>proportion</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1628</th>
      <td>B11 4BW</td>
      <td>Salbutamol_Inha 100mcg (200 D) CFF</td>
      <td>706.0</td>
      <td>0.031059</td>
    </tr>
    <tr>
      <th>3323</th>
      <td>B12 9LP</td>
      <td>Paracet_Tab 500mg</td>
      <td>425.0</td>
      <td>0.024893</td>
    </tr>
    <tr>
      <th>5293</th>
      <td>B18 7AL</td>
      <td>Salbutamol_Inha 100mcg (200 D) CFF</td>
      <td>556.0</td>
      <td>0.027111</td>
    </tr>
    <tr>
      <th>6924</th>
      <td>B21 9RY</td>
      <td>Metformin HCl_Tab 500mg</td>
      <td>1033.0</td>
      <td>0.033294</td>
    </tr>
    <tr>
      <th>9096</th>
      <td>B23 6DJ</td>
      <td>Lansoprazole_Cap 30mg (E/C Gran)</td>
      <td>599.0</td>
      <td>0.021384</td>
    </tr>
  </tbody>
</table>
</div>




```python
max_by_bnf_post['proportion'] = [
    item/postal_total[post_code]
    for post_code, item in 
    zip(max_by_bnf_post['post_code'], max_by_bnf_post['items'])]



```


```python
max_by_bnf_post.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>proportion</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1628</th>
      <td>B11 4BW</td>
      <td>Salbutamol_Inha 100mcg (200 D) CFF</td>
      <td>706.0</td>
      <td>0.031059</td>
    </tr>
    <tr>
      <th>3323</th>
      <td>B12 9LP</td>
      <td>Paracet_Tab 500mg</td>
      <td>425.0</td>
      <td>0.024893</td>
    </tr>
    <tr>
      <th>5293</th>
      <td>B18 7AL</td>
      <td>Salbutamol_Inha 100mcg (200 D) CFF</td>
      <td>556.0</td>
      <td>0.027111</td>
    </tr>
    <tr>
      <th>6924</th>
      <td>B21 9RY</td>
      <td>Metformin HCl_Tab 500mg</td>
      <td>1033.0</td>
      <td>0.033294</td>
    </tr>
    <tr>
      <th>9096</th>
      <td>B23 6DJ</td>
      <td>Lansoprazole_Cap 30mg (E/C Gran)</td>
      <td>599.0</td>
      <td>0.021384</td>
    </tr>
  </tbody>
</table>
</div>




```python
total_by_bnf_post.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>proportion</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>B11 4BW</td>
      <td>3m Health Care_Cavilon Durable Barrier C</td>
      <td>7.0</td>
      <td>0.000308</td>
    </tr>
    <tr>
      <th>1</th>
      <td>B11 4BW</td>
      <td>3m Health Care_Cavilon No Sting Barrier</td>
      <td>2.0</td>
      <td>0.000088</td>
    </tr>
    <tr>
      <th>2</th>
      <td>B11 4BW</td>
      <td>Abasaglar KwikPen_100u/ml 3ml Pf Pen</td>
      <td>2.0</td>
      <td>0.000088</td>
    </tr>
    <tr>
      <th>3</th>
      <td>B11 4BW</td>
      <td>Abidec_Dps</td>
      <td>63.0</td>
      <td>0.002772</td>
    </tr>
    <tr>
      <th>4</th>
      <td>B11 4BW</td>
      <td>Able Spacer + Sml/Med Mask</td>
      <td>1.0</td>
      <td>0.000044</td>
    </tr>
  </tbody>
</table>
</div>




```python
total_by_bnf_post[
    (total_by_bnf_post['post_code'] == 'B11 4BW') &
    (total_by_bnf_post['bnf_name'] == 
     "Salbutamol_Inha 100mcg (200 D) CFF")
]
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>proportion</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1628</th>
      <td>B11 4BW</td>
      <td>Salbutamol_Inha 100mcg (200 D) CFF</td>
      <td>706.0</td>
      <td>0.031059</td>
    </tr>
  </tbody>
</table>
</div>




```python
# total_by_bnf_post = total_by_bnf_post.sort_values('bnf_name')
# total_by_bnf_post = total_by_bnf_post.sort_values('post_code')
# total_by_bnf_post.head()
```


```python
# items_by_region = [("B11 4BW", "Salbutamol_Inha 100mcg (200 D) CFF", 0.0310589063)] * 100
```


```python
# items_by_region = [
#     (post_code, bnf_name, proportion) 
#     for post_code, bnf_name, proportion in 
#     zip(total_by_bnf_post['post_code'], 
#     total_by_bnf_post['bnf_name'], 
#     total_by_bnf_post['proportion'])][:100]

```


```python
items_by_region = [
    (post_code, bnf_name, proportion) 
    for post_code, bnf_name, proportion in 
    zip(max_by_bnf_post['post_code'], 
        max_by_bnf_post['bnf_name'],
        max_by_bnf_post['proportion'])
]


```


```python
items_by_region = items_by_region[:100]
```


```python
items_by_region = list(zip(
    max_by_bnf_post['post_code'], 
    max_by_bnf_post['bnf_name'],
    max_by_bnf_post['proportion']))[:100]
```


```python
grader.score.dw__items_by_region(items_by_region)
```

    ==================
    Your score:  1.0
    ==================


## Question 4: script_anomalies

Drug abuse is a source of human and monetary costs in health care. A first step in identifying practitioners that enable drug abuse is to look for practices where commonly abused drugs are prescribed unusually often. Let's try to find practices that prescribe an unusually high amount of opioids. The opioids we'll look for are given in the list below.


```python
practices.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>code</th>
      <th>name</th>
      <th>addr_1</th>
      <th>addr_2</th>
      <th>borough</th>
      <th>village</th>
      <th>post_code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A81001</td>
      <td>THE DENSHAM SURGERY</td>
      <td>THE HEALTH CENTRE</td>
      <td>LAWSON STREET</td>
      <td>STOCKTON ON TEES</td>
      <td>CLEVELAND</td>
      <td>TS18 1HU</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A81002</td>
      <td>QUEENS PARK MEDICAL CENTRE</td>
      <td>QUEENS PARK MEDICAL CTR</td>
      <td>FARRER STREET</td>
      <td>STOCKTON ON TEES</td>
      <td>CLEVELAND</td>
      <td>TS18 2AW</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A81003</td>
      <td>VICTORIA MEDICAL PRACTICE</td>
      <td>THE HEALTH CENTRE</td>
      <td>VICTORIA ROAD</td>
      <td>HARTLEPOOL</td>
      <td>CLEVELAND</td>
      <td>TS26 8DB</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A81004</td>
      <td>WOODLANDS ROAD SURGERY</td>
      <td>6 WOODLANDS ROAD</td>
      <td>NaN</td>
      <td>MIDDLESBROUGH</td>
      <td>CLEVELAND</td>
      <td>TS1 3BE</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A81005</td>
      <td>SPRINGWOOD SURGERY</td>
      <td>SPRINGWOOD SURGERY</td>
      <td>RECTORY LANE</td>
      <td>GUISBOROUGH</td>
      <td>NaN</td>
      <td>TS14 7DJ</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(chem.shape)
chem.head()
```

    (3487, 2)





<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CHEM SUB</th>
      <th>NAME</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0101010A0</td>
      <td>Alexitol Sodium</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0101010B0</td>
      <td>Almasilate</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0101010C0</td>
      <td>Aluminium Hydroxide</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0101010D0</td>
      <td>Aluminium Hydroxide With Magnesium</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0101010E0</td>
      <td>Hydrotalcite</td>
    </tr>
  </tbody>
</table>
</div>




```python
opioids = ['morphine', 'oxycodone', 'methadone', 'fentanyl', 'pethidine', 'buprenorphine', 'propoxyphene', 'codeine']
```

These are generic names for drugs, not brand names. Generic drug names can be found using the `'bnf_code'` field in `scripts` along with the `chem` table.. Use the list of opioids provided above along with these fields to make a new field in the `scripts` data that flags whether the row corresponds with a opioid prescription.


```python
combined_opioids = '|'.join(opioids)
combined_opioids
```




    'morphine|oxycodone|methadone|fentanyl|pethidine|buprenorphine|propoxyphene|codeine'




```python
# # identify opioids in chems series
# chem['opioids'] = chem['NAME'].str.contains(combined_opioids, case=False).astype(int)

# chem[chem['opioids'] == 1]['opioids'].sum()
```


```python
# script_with_opioids = scripts.merge(chem, how='right', left_on='bnf_code', right_on='CHEM SUB')

# script_with_opioids = scripts.merge(chem, how='left', left_on='bnf_code', right_on='CHEM SUB')
# script_with_opioids.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>bnf_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>nic</th>
      <th>act_cost</th>
      <th>quantity</th>
      <th>CHEM SUB</th>
      <th>NAME</th>
      <th>opioids</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>N85639</td>
      <td>0106020C0</td>
      <td>Bisacodyl_Tab E/C 5mg</td>
      <td>1</td>
      <td>0.39</td>
      <td>0.47</td>
      <td>12</td>
      <td>0106020C0</td>
      <td>Bisacodyl</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>N85639</td>
      <td>0106040M0</td>
      <td>Movicol Plain_Paed Pdr Sach 6.9g</td>
      <td>1</td>
      <td>4.38</td>
      <td>4.07</td>
      <td>30</td>
      <td>0106040M0</td>
      <td>Macrogol 3350</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>N85639</td>
      <td>0301011R0</td>
      <td>Salbutamol_Inha 100mcg (200 D) CFF</td>
      <td>1</td>
      <td>1.50</td>
      <td>1.40</td>
      <td>1</td>
      <td>0301011R0</td>
      <td>Salbutamol</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>N85639</td>
      <td>0304010G0</td>
      <td>Chlorphenamine Mal_Oral Soln 2mg/5ml</td>
      <td>1</td>
      <td>2.62</td>
      <td>2.44</td>
      <td>150</td>
      <td>0304010G0</td>
      <td>Chlorphenamine Maleate</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>N85639</td>
      <td>0401020K0</td>
      <td>Diazepam_Tab 2mg</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.26</td>
      <td>6</td>
      <td>0401020K0</td>
      <td>Diazepam</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
script_with_opioids['opioids'].fillna(int(False), inplace=True)
```

Now for each practice calculate the proportion of its prescriptions containing opioids.

**Hint:** Consider the following list: `[0, 1, 1, 0, 0, 0]`. What proportion of the entries are 1s? What is the mean value?


```python
opioids_per_practice = script_with_opioids.groupby('practice')['opioids'].mean()
opioids_per_practice.head()

```




    practice
    A81005    0.033135
    A81007    0.043269
    A81011    0.046526
    A81012    0.042761
    A81017    0.038122
    Name: opioids, dtype: float64




```python
mean_of_opioids = script_with_opioids['opioids'].mean()
# mean_of_opioids['relative'] = script_with_opioids[]
mean_of_opioids = 0.03580276471367961
```

How do these proportions compare to the overall opioid prescription rate? Subtract off the proportion of all prescriptions that are opioids from each practice's proportion.


```python
relative_opioids_per_practice = opioids_per_practice - mean_of_opioids

relative_opioids_per_practice.head()


```




    practice
    A81005   -0.002668
    A81007    0.007466
    A81011    0.010724
    A81012    0.006958
    A81017    0.002319
    Name: opioids, dtype: float64



Now that we know the difference between each practice's opioid prescription rate and the overall rate, we can identify which practices prescribe opioids at above average or below average rates. However, are the differences from the overall rate important or just random deviations? In other words, are the differences from the overall rate big or small?

To answer this question we have to quantify the difference we would typically expect between a given practice's opioid prescription rate and the overall rate. This quantity is called the **standard error**, and is related to the **standard deviation**, $\sigma$. The standard error in this case is

$$ \frac{\sigma}{\sqrt{n}} $$

where $n$ is the number of prescriptions each practice made. Calculate the standard error for each practice. Then divide `relative_opioids_per_practice` by the standard errors. We'll call the final result `opioid_scores`.


```python
script_with_opioids.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>bnf_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>nic</th>
      <th>act_cost</th>
      <th>quantity</th>
      <th>CHEM SUB</th>
      <th>NAME</th>
      <th>opioids</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>N85639</td>
      <td>0106020C0</td>
      <td>Bisacodyl_Tab E/C 5mg</td>
      <td>1</td>
      <td>0.39</td>
      <td>0.47</td>
      <td>12</td>
      <td>0106020C0</td>
      <td>Bisacodyl</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>N85639</td>
      <td>0106040M0</td>
      <td>Movicol Plain_Paed Pdr Sach 6.9g</td>
      <td>1</td>
      <td>4.38</td>
      <td>4.07</td>
      <td>30</td>
      <td>0106040M0</td>
      <td>Macrogol 3350</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>N85639</td>
      <td>0301011R0</td>
      <td>Salbutamol_Inha 100mcg (200 D) CFF</td>
      <td>1</td>
      <td>1.50</td>
      <td>1.40</td>
      <td>1</td>
      <td>0301011R0</td>
      <td>Salbutamol</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>N85639</td>
      <td>0304010G0</td>
      <td>Chlorphenamine Mal_Oral Soln 2mg/5ml</td>
      <td>1</td>
      <td>2.62</td>
      <td>2.44</td>
      <td>150</td>
      <td>0304010G0</td>
      <td>Chlorphenamine Maleate</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>N85639</td>
      <td>0401020K0</td>
      <td>Diazepam_Tab 2mg</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.26</td>
      <td>6</td>
      <td>0401020K0</td>
      <td>Diazepam</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
standard_error_per_practice = script_with_opioids[
    'opioids'].std() / np.sqrt(script_with_opioids[
    'practice'].value_counts())

standard_error_per_practice

# N83028    0.003702
# L83100    0.003733
# D81043    0.003981
# B81008    0.004033
# B81026    0.004075
# G81013    0.004093
# C84013    0.004170
# M83006    0.004183
```




    N83028    0.003481
    L83100    0.003510
    D81043    0.003744
    B81008    0.003793
    B81026    0.003832
    G81013    0.003849
    C84013    0.003921
    M83006    0.003934
    A81034    0.003951
    P81123    0.003955
    D83012    0.003964
    J81041    0.003977
    P81681    0.003981
    A81017    0.004004
    P81072    0.004006
    Y03079    0.004006
    B86016    0.004026
    M84012    0.004063
    P81100    0.004067
    G82126    0.004079
    G82020    0.004082
    N81062    0.004091
    P85013    0.004096
    M85033    0.004113
    E82124    0.004120
    K83051    0.004128
    P81140    0.004131
    P89015    0.004134
    C85022    0.004137
    H85653    0.004142
                ...   
    Y05269    0.065663
    Y01852    0.070197
    Y02947    0.070197
    Y04080    0.070197
    Y00908    0.070197
    Y05488    0.075821
    Y00828    0.075821
    Y04147    0.083058
    Y05457    0.083058
    Y05320    0.083058
    Y04030    0.092862
    N85647    0.092862
    Y03699    0.092862
    Y04692    0.092862
    Y01943    0.107227
    N83612    0.107227
    Y02318    0.107227
    Y03863    0.107227
    Y03408    0.107227
    Y05371    0.131326
    Y03006    0.131326
    Y01667    0.131326
    Y00043    0.131326
    Y00581    0.131326
    Y03179    0.185723
    Y03010    0.185723
    Y05366    0.185723
    Y03472    0.185723
    Y01174    0.185723
    C85617    0.185723
    Name: practice, Length: 856, dtype: float64




```python
opioid_scores = relative_opioids_per_practice / standard_error_per_practice
opioid_scores.head()
```




    A81005   -0.558089
    A81007    1.534016
    A81011    2.287123
    A81012    1.367820
    A81017    0.579112
    dtype: float64



The quantity we have calculated in `opioid_scores` is called a **z-score**:

$$ \frac{\bar{X} - \mu}{\sqrt{\sigma^2/n}} $$

Here $\bar{X}$ corresponds with the proportion for each practice, $\mu$ corresponds with the proportion across all practices, $\sigma^2$ corresponds with the variance of the proportion across all practices, and $n$ is the number of prescriptions made by each practice. Notice $\bar{X}$ and $n$ will be different for each practice, while $\mu$ and $\sigma$ are determined across all prescriptions, and so are the same for every z-score. The z-score is a useful statistical tool used for hypothesis testing, finding outliers, and comparing data about different types of objects or events.

Now that we've calculated this statistic, take the 100 practices with the largest z-score. Return your result as a list of tuples in the form `(practice_name, z-score, number_of_scripts)`. Sort your tuples by z-score in descending order. Note that some practice codes will correspond with multiple names. In this case, use the first match when sorting names alphabetically.


```python
top_opioids = opioid_scores.sort_values(ascending=False)[:100]

top_opioids.head()

```




    Y01852    11.700544
    Y03006     7.342009
    Y03668     6.153067
    G81703     5.125103
    Y04997     4.960870
    dtype: float64




```python
top_opioids = pd.DataFrame(top_opioids.rename('z_score')).reset_index()
```


```python
top_opioids.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>z_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Y01852</td>
      <td>11.700544</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Y03006</td>
      <td>7.342009</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Y03668</td>
      <td>6.153067</td>
    </tr>
    <tr>
      <th>3</th>
      <td>G81703</td>
      <td>5.125103</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Y04997</td>
      <td>4.960870</td>
    </tr>
  </tbody>
</table>
</div>




```python
unique_practices.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>code</th>
      <th>name</th>
      <th>addr_1</th>
      <th>addr_2</th>
      <th>borough</th>
      <th>village</th>
      <th>post_code</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A81001</td>
      <td>THE DENSHAM SURGERY</td>
      <td>THE HEALTH CENTRE</td>
      <td>LAWSON STREET</td>
      <td>STOCKTON ON TEES</td>
      <td>CLEVELAND</td>
      <td>TS18 1HU</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A81002</td>
      <td>QUEENS PARK MEDICAL CENTRE</td>
      <td>QUEENS PARK MEDICAL CTR</td>
      <td>FARRER STREET</td>
      <td>STOCKTON ON TEES</td>
      <td>CLEVELAND</td>
      <td>TS18 2AW</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A81003</td>
      <td>VICTORIA MEDICAL PRACTICE</td>
      <td>MCKENZIE HOUSE</td>
      <td>17 KENDAL ROAD</td>
      <td>HARTLEPOOL</td>
      <td>CLEVELAND</td>
      <td>TS25 1QU</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A81004</td>
      <td>WOODLANDS ROAD SURGERY</td>
      <td>6 WOODLANDS ROAD</td>
      <td>ACKLAM</td>
      <td>MIDDLESBROUGH</td>
      <td>CLEVELAND</td>
      <td>TS1 3BE</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A81005</td>
      <td>SPRINGWOOD SURGERY</td>
      <td>SPRINGWOOD SURGERY</td>
      <td>RECTORY LANE</td>
      <td>GUISBOROUGH</td>
      <td>NaN</td>
      <td>TS14 7DJ</td>
    </tr>
  </tbody>
</table>
</div>




```python
results = top_opioids.merge(unique_practices[['name', 'code']],
                 how='left',
                 left_on='index',
                 right_on='code')
```


```python
results = results.merge(pd.DataFrame(scripts.groupby('practice').size().rename('n_scripts')),
                           how='left',
                           left_on='code',
                           right_index=True)
```


```python
results = results[['name', 'z_score', 'n_scripts']]

```


```python
# anomalies = [("NATIONAL ENHANCED SERVICE", 11.6958178629, 7)] * 100

anomalies = [tuple(row) for row in results.values]

anomalies[:10]
```




    [('NATIONAL ENHANCED SERVICE', 11.70054397039536, 7),
     ('OUTREACH SERVICE NH / RH', 7.342008618255846, 2),
     ('BRISDOC HEALTHCARE SERVICES OOH', 6.153067108434004, 60),
     ('H&R P C SPECIAL SCHEME', 5.125102555855576, 36),
     ('HMR BARDOC OOH', 4.960870243261194, 321),
     ('INTEGRATED CARE 24 LTD (CWSX OOH)', 4.8908536840257515, 426),
     ('DARWEN HEALTHCARE', 4.829789791895336, 1917),
     ('THE LIMES MEDICAL PRACTICE', 4.534639855939941, 1321),
     ('IC24 LTD (BRIGHTON & HOVE OOH)', 4.336798739150689, 357),
     ('OLDHAM 7 DAY ACCESS HUB2 OOH', 4.313526364931071, 56)]



# Mark here 


```python
opioids = ['morphine', 'oxycodone', 'methadone', 'fentanyl', 'pethidine', 'buprenorphine', 'propoxyphene', 'codeine']
```


```python
combined_opioids = '|'.join(opioids)
combined_opioids
```




    'morphine|oxycodone|methadone|fentanyl|pethidine|buprenorphine|propoxyphene|codeine'




```python
# identify opioids in chems series
mask = chem['NAME'].str.contains(combined_opioids, case=False)
opioid_codes = chem[mask]['CHEM SUB']

```


```python
chem.groupby(chem.columns.tolist(),as_index=False).size().max()
```




    1




```python
scripts['opioids'] = scripts['bnf_code'].isin(opioid_codes).astype(int)
```


```python
opioids_per_practice = scripts.groupby('practice')['opioids'].mean()
opioids_per_practice.head()
```




    practice
    A81005    0.033179
    A81007    0.043329
    A81011    0.046556
    A81012    0.042793
    A81017    0.038140
    Name: opioids, dtype: float64




```python
relative_opioids_per_practice = opioids_per_practice - scripts['opioids'].mean()
relative_opioids_per_practice.head()

```




    practice
    A81005   -0.002624
    A81007    0.007526
    A81011    0.010753
    A81012    0.006990
    A81017    0.002337
    Name: opioids, dtype: float64




```python
relative_opioids_per_practice.plot(kind='hist', xlim=(-0.3, 0.3))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fdf0ca2b240>




![png](output_93_1.png)



```python
standard_error_per_practice = np.sqrt(scripts[
    'opioids'].var() / scripts[
    'practice'].value_counts())
standard_error_per_practice.head()

```




    N83028    0.003484
    L83100    0.003513
    D81043    0.003747
    B81008    0.003796
    B81026    0.003835
    Name: practice, dtype: float64




```python
opioid_scores = relative_opioids_per_practice / standard_error_per_practice
opioid_scores.head()
```




    A81005   -0.548306
    A81007    1.544557
    A81011    2.291795
    A81012    1.373060
    A81017    0.583168
    dtype: float64




```python
top_opioids = opioid_scores.sort_values(ascending=False)[:100]
top_opioids.head()
```




    Y01852    11.695818
    Y03006     7.339043
    Y03668     6.150582
    G81703     5.123032
    Y04997     4.958866
    dtype: float64




```python
top_opioids.rename('z_score').head()
```




    Y01852    11.695818
    Y03006     7.339043
    Y03668     6.150582
    G81703     5.123032
    Y04997     4.958866
    Name: z_score, dtype: float64




```python
top_opioids = pd.DataFrame(top_opioids.rename('z_score')).reset_index()
top_opioids.columns = ['practice', 'z_score']
top_opioids.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>z_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Y01852</td>
      <td>11.695818</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Y03006</td>
      <td>7.339043</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Y03668</td>
      <td>6.150582</td>
    </tr>
    <tr>
      <th>3</th>
      <td>G81703</td>
      <td>5.123032</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Y04997</td>
      <td>4.958866</td>
    </tr>
  </tbody>
</table>
</div>




```python
top_opioids.z_score.hist()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fdf0b6198d0>




![png](output_99_1.png)



```python
# groupby code, select the name and pick the alphabetically first name; e.g min('a', 'b') return a
unique_practices = practices.groupby('code')['name'].min()
unique_practices = pd.DataFrame(unique_practices)
```


```python
unique_practices.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
    </tr>
    <tr>
      <th>code</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>A81001</th>
      <td>THE DENSHAM SURGERY</td>
    </tr>
    <tr>
      <th>A81002</th>
      <td>QUEENS PARK MEDICAL CENTRE</td>
    </tr>
    <tr>
      <th>A81003</th>
      <td>VICTORIA MEDICAL PRACTICE</td>
    </tr>
    <tr>
      <th>A81004</th>
      <td>BLUEBELL MEDICAL CENTRE</td>
    </tr>
    <tr>
      <th>A81005</th>
      <td>SPRINGWOOD SURGERY</td>
    </tr>
  </tbody>
</table>
</div>




```python
top_opioids.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>z_score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Y01852</td>
      <td>11.695818</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Y03006</td>
      <td>7.339043</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Y03668</td>
      <td>6.150582</td>
    </tr>
    <tr>
      <th>3</th>
      <td>G81703</td>
      <td>5.123032</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Y04997</td>
      <td>4.958866</td>
    </tr>
  </tbody>
</table>
</div>




```python
# merge unique practices with top opioids in the know that practice 
# in top_opioids corresponds with index code of unique practices
results = top_opioids.merge(unique_practices,
                           how='left',
                           left_on='practice',
                           right_index=True)
results.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>z_score</th>
      <th>name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Y01852</td>
      <td>11.695818</td>
      <td>NATIONAL ENHANCED SERVICE</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Y03006</td>
      <td>7.339043</td>
      <td>OUTREACH SERVICE NH / RH</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Y03668</td>
      <td>6.150582</td>
      <td>BRISDOC HEALTHCARE SERVICES OOH</td>
    </tr>
    <tr>
      <th>3</th>
      <td>G81703</td>
      <td>5.123032</td>
      <td>H&amp;R P C SPECIAL SCHEME</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Y04997</td>
      <td>4.958866</td>
      <td>HMR BARDOC OOH</td>
    </tr>
  </tbody>
</table>
</div>




```python
results = results.merge(pd.DataFrame(scripts.groupby('practice').size().rename('n_scripts')),
                        how='left',
                        left_on='practice',
                        right_index=True)
results.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>z_score</th>
      <th>name</th>
      <th>n_scripts</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Y01852</td>
      <td>11.695818</td>
      <td>NATIONAL ENHANCED SERVICE</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Y03006</td>
      <td>7.339043</td>
      <td>OUTREACH SERVICE NH / RH</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Y03668</td>
      <td>6.150582</td>
      <td>BRISDOC HEALTHCARE SERVICES OOH</td>
      <td>60</td>
    </tr>
    <tr>
      <th>3</th>
      <td>G81703</td>
      <td>5.123032</td>
      <td>H&amp;R P C SPECIAL SCHEME</td>
      <td>36</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Y04997</td>
      <td>4.958866</td>
      <td>HMR BARDOC OOH</td>
      <td>321</td>
    </tr>
  </tbody>
</table>
</div>




```python
results = results[['name', 'z_score', 'n_scripts']]

results.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>z_score</th>
      <th>n_scripts</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NATIONAL ENHANCED SERVICE</td>
      <td>11.695818</td>
      <td>7</td>
    </tr>
    <tr>
      <th>1</th>
      <td>OUTREACH SERVICE NH / RH</td>
      <td>7.339043</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BRISDOC HEALTHCARE SERVICES OOH</td>
      <td>6.150582</td>
      <td>60</td>
    </tr>
    <tr>
      <th>3</th>
      <td>H&amp;R P C SPECIAL SCHEME</td>
      <td>5.123032</td>
      <td>36</td>
    </tr>
    <tr>
      <th>4</th>
      <td>HMR BARDOC OOH</td>
      <td>4.958866</td>
      <td>321</td>
    </tr>
  </tbody>
</table>
</div>




```python
results['z_score'] = np.round(results['z_score'], 10)
```


```python
anomalies = [tuple(row) for row in results.values]
anomalies[:5]
```




    [('NATIONAL ENHANCED SERVICE', 11.6958178629, 7),
     ('OUTREACH SERVICE NH / RH', 7.3390430192, 2),
     ('BRISDOC HEALTHCARE SERVICES OOH', 6.1505817491, 60),
     ('H&R P C SPECIAL SCHEME', 5.123032414, 36),
     ('HMR BARDOC OOH', 4.9588664385, 321)]




```python
grader.score.dw__script_anomalies(anomalies)
```

    ==================
    Your score:  1.0
    ==================


## Question 5: script_growth

Another way to identify anomalies is by comparing current data to historical data. In the case of identifying sites of drug abuse, we might compare a practice's current rate of opioid prescription to their rate 5 or 10 years ago. Unless the nature of the practice has changed, the profile of drugs they prescribe should be relatively stable. We might also want to identify trends through time for business reasons, identifying drugs that are gaining market share. That's what we'll do in this question.

We'll load in beneficiary data from 6 months earlier, June 2016, and calculate the percent growth in prescription rate from June 2016 to January 2017 for each `bnf_name`. We'll return the 50 items with largest growth and the 50 items with the largest shrinkage (i.e. negative percent growth) as a list of tuples sorted by growth rate in descending order in the format `(script_name, growth_rate, raw_2016_count)`. You'll notice that many of the 50 fastest growing items have low counts of prescriptions in 2016. Filter out any items that were prescribed less than 50 times.


```python
!ls dw-data
```

    201606scripts_sample.csv.gz  chem.csv.gz
    201701scripts_sample.csv.gz  practices.csv.gz



```python
scripts16 = pd.read_csv('dw-data/201606scripts_sample.csv.gz')
scripts16.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>bnf_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>nic</th>
      <th>act_cost</th>
      <th>quantity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>N85638</td>
      <td>0301011R0</td>
      <td>Salamol_Inha 100mcg (200 D) CFF (Teva)</td>
      <td>2</td>
      <td>2.92</td>
      <td>2.73</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>N85638</td>
      <td>0301011R0</td>
      <td>Easyhaler_Salbutamol Sulf 200mcg (200D)</td>
      <td>1</td>
      <td>6.63</td>
      <td>6.15</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>N85638</td>
      <td>0301020I0</td>
      <td>Ipratrop Brom_Inh Soln 500mcg/2ml Ud</td>
      <td>1</td>
      <td>1.77</td>
      <td>1.75</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3</th>
      <td>N85638</td>
      <td>0301020I0</td>
      <td>Ipratrop Brom_Inh Soln 250mcg/1ml Ud</td>
      <td>1</td>
      <td>4.47</td>
      <td>4.15</td>
      <td>20</td>
    </tr>
    <tr>
      <th>4</th>
      <td>N85638</td>
      <td>0302000C0</td>
      <td>Clenil Modulite_Inha 50mcg (200D)</td>
      <td>1</td>
      <td>3.70</td>
      <td>3.44</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
scripts16.bnf_name.value_counts().astype(float).head()
```




    GlucoRX FinePoint Needles Pen Inj Screw     1532.0
    3m Health Care_Cavilon Durable Barrier C     825.0
    Fluclox Sod_Cap 500mg                        796.0
    Amoxicillin_Cap 500mg                        790.0
    Prednisolone_Tab 5mg                         786.0
    Name: bnf_name, dtype: float64




```python
scripts.bnf_name.value_counts().astype(float).head()
```




    GlucoRX FinePoint Needles Pen Inj Screw     1718.0
    3m Health Care_Cavilon Durable Barrier C     816.0
    Prednisolone_Tab 5mg                         785.0
    Fluclox Sod_Cap 500mg                        783.0
    Amoxicillin_Cap 500mg                        777.0
    Name: bnf_name, dtype: float64




```python
pct_growth = (scripts.bnf_name.value_counts().astype(float)
              /scripts16.bnf_name.value_counts().astype(float)
              - 1)
```


```python
top50 = pct_growth.sort_values(ascending=False).dropna()[:50]
top50.head()
```




    Vensir XL_Cap 225mg                     92.000
    Fludroxycortide_Tape 7.5cm x 20cm       52.000
    Tamiflu_Cap 75mg                        43.000
    Enstilar_Foam Aero 50mcg/0.5mg/g        27.125
    Memantine HCl_Orodisper Tab 10mg S/F    27.000
    Name: bnf_name, dtype: float64




```python
bottom50 = pct_growth.sort_values().dropna()[:50]
bottom50.head()
```




    Polyalc_Eye Dps 1.4%        -0.996324
    Macrogol_Co Oral Pdr Sach   -0.971429
    Benzoyl Per_Crm 5%          -0.960000
    Climesse_Tab                -0.942029
    Univer_Cap 180mg            -0.941176
    Name: bnf_name, dtype: float64




```python
top_growth = pd.concat([top50, bottom50])
top_growth
```




    Polyalc_Eye Dps 1.4%                       -0.996324
    Macrogol_Co Oral Pdr Sach                  -0.971429
    Benzoyl Per_Crm 5%                         -0.960000
    Climesse_Tab                               -0.942029
    Univer_Cap 180mg                           -0.941176
    Rimexolone_Eye Dps 10mg/ml                 -0.938776
    Sunsense_Toddler Suncare Milk Spf 50+      -0.938776
    Oxprenolol HCl_Tab 160mg M/R               -0.928571
    Climaval_Tab 1mg                           -0.926471
    Ovysmen_Tab                                -0.925373
    Abilify_Tab 15mg                           -0.916667
    Hydroxyzine HCl_Oral Soln 10mg/5ml         -0.914894
    Orphenadrine HCl_Tab 50mg                  -0.911765
    Vexol_Eye Dps 10mg/ml                      -0.911111
    Acondro_Tab 0.03mg/3mg                     -0.909091
    Binovum_Tab                                -0.909091
    Levofloxacin_Eye Dps 5mg/ml 0.5ml Ud P/F   -0.909091
    Climaval_Tab 2mg                           -0.901515
    Triapin_Tab 5mg/5mg M/R                    -0.900000
    Co-Danthramer_Cap 25mg/200mg               -0.900000
    Drawtex 10cm x 10cm Wound Dress Protease   -0.900000
    Voltarol SR_Tab 75mg                       -0.900000
    Sporanox-Pulse_Cap 100mg                   -0.900000
    Resource_Fruit Liq (Orange)                -0.900000
    Eumocream_Crm 25%                          -0.900000
    Sunsense_Lip Balm Spf 50                   -0.900000
    Climagest_Tab 2mg                          -0.893939
    Surg Suture W1621T Non Absorb Ster Syn     -0.888889
    Prontosan Wound Gel X 50g Wound Dress H/   -0.888889
    Telfast 30_Tab 30mg                        -0.888889
                                                  ...   
    Drawtex 10cm x 10cm Wound Dress Protease   -0.900000
    Voltarol SR_Tab 75mg                       -0.900000
    Sporanox-Pulse_Cap 100mg                   -0.900000
    Resource_Fruit Liq (Orange)                -0.900000
    Eumocream_Crm 25%                          -0.900000
    Sunsense_Lip Balm Spf 50                   -0.900000
    Climagest_Tab 2mg                          -0.893939
    Surg Suture W1621T Non Absorb Ster Syn     -0.888889
    Prontosan Wound Gel X 50g Wound Dress H/   -0.888889
    Telfast 30_Tab 30mg                        -0.888889
    Barkat_G/F W/F Baguette P/Bke              -0.888889
    AquADEKS_Cap                               -0.888889
    Therabite Bite Pad                         -0.888889
    Welland_FreeStyle Vie Urost Pouch Tapere   -0.888889
    PanOxyl 10 Aquagel_Gel 10%                 -0.888889
    Colestid_Gran Sach 0.2% 5g                 -0.888889
    Ecolab_Atmocol Pocket A/Spy 25ml           -0.882353
    Testosterone Undecan_Cap 40mg              -0.882353
    Mirapexin_Tab 2.62mg M/R                   -0.875000
    Jobst Elvarex Acc For L/Extrem Zipper      -0.875000
    Restandol Testocap_Cap 40mg                -0.875000
    Convatec_Esteem Syner Pouch+Fltr+Invis O   -0.875000
    Hypromellose_Eye Dps 0.25%                 -0.875000
    Medicareplus_Medi Lifteez Non Sting Medi   -0.875000
    Hepatyrix_Vac 1440u/25mcg/ml 1ml Pfs       -0.875000
    Loratadine_Oral Lyophilisate Tab10mg S/F   -0.857143
    Somatuline Autogel_Inj 120mg/0.5ml SSPfs   -0.857143
    Ucerax_Syr 2mg/ml                          -0.857143
    Lopresor Sr_Tab 200mg                      -0.857143
    Pylobactell_Tab Solb 100mg                 -0.857143
    Name: bnf_name, Length: 100, dtype: float64




```python
growth = pd.concat([pct_growth.rename('pct_growth'),
                   scripts16.bnf_name.value_counts().rename('count')],
                   axis=1).dropna()

filter_growth = growth[growth['count'] >= 50].sort_values('pct_growth', ascending=False)
filter_growth.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pct_growth</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Butec_Transdermal Patch 5mcg/hr</th>
      <td>3.467742</td>
      <td>62.0</td>
    </tr>
    <tr>
      <th>Butec_Transdermal Patch 10mcg/hr</th>
      <td>3.000000</td>
      <td>69.0</td>
    </tr>
    <tr>
      <th>Fostair NEXThaler_Inh 200mcg/6mcg (120D)</th>
      <td>1.430233</td>
      <td>86.0</td>
    </tr>
    <tr>
      <th>Pneumococcal_Vac 0.5ml Vl (23 Valent)</th>
      <td>1.269430</td>
      <td>193.0</td>
    </tr>
    <tr>
      <th>Spiolto Respimat_Inha2.5/2.5mcg(60D)+Dev</th>
      <td>1.269231</td>
      <td>52.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
extreme_growth = pd.concat([filter_growth.head(50), filter_growth.tail(50)])
extreme_growth.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pct_growth</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Butec_Transdermal Patch 5mcg/hr</th>
      <td>3.467742</td>
      <td>62.0</td>
    </tr>
    <tr>
      <th>Butec_Transdermal Patch 10mcg/hr</th>
      <td>3.000000</td>
      <td>69.0</td>
    </tr>
    <tr>
      <th>Fostair NEXThaler_Inh 200mcg/6mcg (120D)</th>
      <td>1.430233</td>
      <td>86.0</td>
    </tr>
    <tr>
      <th>Pneumococcal_Vac 0.5ml Vl (23 Valent)</th>
      <td>1.269430</td>
      <td>193.0</td>
    </tr>
    <tr>
      <th>Spiolto Respimat_Inha2.5/2.5mcg(60D)+Dev</th>
      <td>1.269231</td>
      <td>52.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# script_growth = [("Butec_Transdermal Patch 5mcg\/hr", 3.4677419355, 62.0)] * 100

script_growth = [tuple(row) for row in extreme_growth.values]
script_growth[:5]
```




    [(3.467741935483871, 62.0),
     (3.0, 69.0),
     (1.4302325581395348, 86.0),
     (1.2694300518134716, 193.0),
     (1.2692307692307692, 52.0)]




```python
# script_growth = [("Butec_Transdermal Patch 5mcg\/hr", 3.4677419355, 62.0)] * 100

script_growth = [tuple(row) for row in extreme_growth.reset_index().values]
script_growth[:5]
```




    [('Butec_Transdermal Patch 5mcg/hr', 3.467741935483871, 62.0),
     ('Butec_Transdermal Patch 10mcg/hr', 3.0, 69.0),
     ('Fostair NEXThaler_Inh 200mcg/6mcg (120D)', 1.4302325581395348, 86.0),
     ('Pneumococcal_Vac 0.5ml Vl (23 Valent)', 1.2694300518134716, 193.0),
     ('Spiolto Respimat_Inha2.5/2.5mcg(60D)+Dev', 1.2692307692307692, 52.0)]




```python
script_growth = [tuple(row) for row in extreme_growth.itertuples()]
script_growth[:5]
```




    [('Butec_Transdermal Patch 5mcg/hr', 3.467741935483871, 62.0),
     ('Butec_Transdermal Patch 10mcg/hr', 3.0, 69.0),
     ('Fostair NEXThaler_Inh 200mcg/6mcg (120D)', 1.4302325581395348, 86.0),
     ('Pneumococcal_Vac 0.5ml Vl (23 Valent)', 1.2694300518134716, 193.0),
     ('Spiolto Respimat_Inha2.5/2.5mcg(60D)+Dev', 1.2692307692307692, 52.0)]




```python
grader.score.dw__script_growth(script_growth)
```

    ==================
    Your score:  1.0
    ==================


## Question 6: rare_scripts

Does a practice's prescription costs originate from routine care or from reliance on rarely prescribed treatments? Commonplace treatments can carry lower costs than rare treatments because of efficiencies in large-scale production. While some specialist practices can't help but avoid prescribing rare medicines because there are no alternatives, some practices may be prescribing a unnecessary amount of brand-name products when generics are available. Let's identify practices whose costs disproportionately originate from rarely prescribed items.

First we have to identify which `'bnf_code'` are rare. To do this, find the probability $p$ of a prescription having a particular `'bnf_code'` if the `'bnf_code'` was randomly chosen from the unique options in the beneficiary data. We will call a `'bnf_code'` rare if it is prescribed at a rate less than $0.1p$.


```python
p = 1. / scripts['bnf_code'].nunique()  # probabilility of bnf_code being precribe
rates = scripts['bnf_code'].value_counts() / scripts['bnf_code'].count()
mask = rates < .1 * p
rare_codes = rates[mask].index

```




    0.0005063291139240507




```python
scripts['rare'] = scripts['bnf_code'].isin(rare_codes)
scripts.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>bnf_code</th>
      <th>bnf_name</th>
      <th>items</th>
      <th>nic</th>
      <th>act_cost</th>
      <th>quantity</th>
      <th>rare</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>N85639</td>
      <td>0106020C0</td>
      <td>Bisacodyl_Tab E/C 5mg</td>
      <td>1</td>
      <td>0.39</td>
      <td>0.47</td>
      <td>12</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>N85639</td>
      <td>0106040M0</td>
      <td>Movicol Plain_Paed Pdr Sach 6.9g</td>
      <td>1</td>
      <td>4.38</td>
      <td>4.07</td>
      <td>30</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>N85639</td>
      <td>0301011R0</td>
      <td>Salbutamol_Inha 100mcg (200 D) CFF</td>
      <td>1</td>
      <td>1.50</td>
      <td>1.40</td>
      <td>1</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>N85639</td>
      <td>0304010G0</td>
      <td>Chlorphenamine Mal_Oral Soln 2mg/5ml</td>
      <td>1</td>
      <td>2.62</td>
      <td>2.44</td>
      <td>150</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>N85639</td>
      <td>0401020K0</td>
      <td>Diazepam_Tab 2mg</td>
      <td>1</td>
      <td>0.16</td>
      <td>0.26</td>
      <td>6</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>



Now for each practice, calculate the proportion of costs that originate from prescription of rare treatments (i.e. rare `'bnf_code'`). Use the `'act_cost'` field for this calculation.


```python
rare_cost_prop = (scripts[scripts['rare']].groupby('practice')['act_cost'].sum() 
                  / scripts.groupby('practice')['act_cost'].sum()).fillna(0)

rare_cost_prop.head()
```




    practice
    A81005    0.012017
    A81007    0.008381
    A81011    0.005116
    A81012    0.013747
    A81017    0.007359
    Name: act_cost, dtype: float64



Now we will calculate a z-score for each practice based on this proportion.
First take the difference of `rare_cost_prop` and the proportion of costs originating from rare treatments across all practices.


```python
relative_rare_cost_prop = (rare_cost_prop
                          - scripts[scripts['rare']]['act_cost'].sum() 
                           / scripts['act_cost'].sum())

relative_rare_cost_prop.head()

```




    practice
    A81005   -0.003946
    A81007   -0.007582
    A81011   -0.010847
    A81012   -0.002216
    A81017   -0.008604
    Name: act_cost, dtype: float64



Now we will estimate the standard errors (i.e. the denominator of the z-score) by simply taking the standard deviation of this difference.


```python
standard_errors = relative_rare_cost_prop.std()
standard_errors
```




    0.06050888706745139



Finally compute the z-scores. Return the practices with the top 100 z-scores in the form `(post_code, practice_name, z-score)`. Note that some practice codes will correspond with multiple names. In this case, use the first match when sorting names alphabetically.


```python
rare_scores = (relative_rare_cost_prop / standard_errors).reset_index()
rare_scores.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>act_cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A81005</td>
      <td>-0.065216</td>
    </tr>
    <tr>
      <th>1</th>
      <td>A81007</td>
      <td>-0.125308</td>
    </tr>
    <tr>
      <th>2</th>
      <td>A81011</td>
      <td>-0.179263</td>
    </tr>
    <tr>
      <th>3</th>
      <td>A81012</td>
      <td>-0.036615</td>
    </tr>
    <tr>
      <th>4</th>
      <td>A81017</td>
      <td>-0.142190</td>
    </tr>
  </tbody>
</table>
</div>




```python
unique_practices = practices.groupby('code')['name'].min()

```


```python
rare_scores['practice_name'] = \
rare_scores['practice'].apply(lambda code: unique_practices[code])
rare_scores.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>practice</th>
      <th>practice_name</th>
      <th>act_cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>765</th>
      <td>Y03472</td>
      <td>CONSULTANT DIABETES TEAM</td>
      <td>16.262687</td>
    </tr>
    <tr>
      <th>831</th>
      <td>Y05320</td>
      <td>DMC COMMUNITY DERMATOLOGY RBWF</td>
      <td>15.128648</td>
    </tr>
    <tr>
      <th>793</th>
      <td>Y04404</td>
      <td>OUTPATIENTS JUBILEE HEALTH CENTRE</td>
      <td>7.542139</td>
    </tr>
    <tr>
      <th>766</th>
      <td>Y03484</td>
      <td>DMC COMMUNITY DERMATOLOGY CLINIC</td>
      <td>7.287222</td>
    </tr>
    <tr>
      <th>794</th>
      <td>Y04424</td>
      <td>DMC HEALTHCARE</td>
      <td>6.838614</td>
    </tr>
  </tbody>
</table>
</div>




```python
rare_scores = rare_scores[['practice', 'practice_name', 'act_cost']]
rare_scores.sort_values('act_cost', ascending=False, inplace=True)
```


```python
# rare_scripts = [("Y03472", "CONSULTANT DIABETES TEAM", 16.2626871247)] * 100
rare_scripts = [tuple(x) for x in rare_scores.values][:100]
rare_scripts[:5]
```




    [('Y03472', 'CONSULTANT DIABETES TEAM', 16.262687124655073),
     ('Y05320', 'DMC COMMUNITY DERMATOLOGY RBWF', 15.128648195416869),
     ('Y04404', 'OUTPATIENTS JUBILEE HEALTH CENTRE', 7.54213935610462),
     ('Y03484', 'DMC COMMUNITY DERMATOLOGY CLINIC', 7.287222200297828),
     ('Y04424', 'DMC HEALTHCARE', 6.838614181432866)]




```python
grader.score.dw__rare_scripts(rare_scripts)
```

    ==================
    Your score:  1.0
    ==================


*Copyright &copy; 2019 The Data Incubator.  All rights reserved.*
